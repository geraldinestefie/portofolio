CREATE DATABASE BlauJackeJacket

USE BlauJackeJacket

--MsCustomer
CREATE TABLE MsCustomer(
	customerID CHAR(5) PRIMARY KEY CHECK (customerID LIKE 'CU[0-9][0-9][0-9]'),
	customerName VARCHAR(70) NOT NULL,
	customerGender VARCHAR(7) NOT NULL,
	customerDOB DATE NOT NULL,
	CONSTRAINT checkCustomerGender CHECK (customerGender IN ('Male','Female')),
)
SELECT * FROM MsCustomer
DROP TABLE MsCustomer

--MsStaff
CREATE TABLE MsStaff(
	staffID CHAR(5) PRIMARY KEY CHECK (staffID LIKE 'ST[0-9][0-9][0-9]'),
	staffName VARCHAR(70) NOT NULL,
	staffGender VARCHAR(7) NOT NULL,
	customerDOB DATE NOT NULL,
	staffSalary INT NOT NULL,
	CONSTRAINT checkStaffName CHECK (DATALENGTH(staffName)>=3),
	CONSTRAINT checkStaffGender CHECK (staffGender IN ('Male','Female')),
	CONSTRAINT checkStaffSalary CHECK (staffSalary BETWEEN 1000000 AND 20000000)
)
SELECT * FROM MsStaff
drop table MsStaff

--MsVendor
CREATE TABLE MsVendor(
	vendorID CHAR(5) PRIMARY KEY CHECK (vendorID LIKE 'VE[0-9][0-9][0-9]'),
	vendorName VARCHAR(70) NOT NULL,
	vendorAddress VARCHAR(30) NOT NULL CHECK (vendorAddress LIKE '% Street'),
	vendorEmail VARCHAR(50) NOT NULL CHECK (vendorEmail LIKE '%@%'),
	CONSTRAINT checkVendorName CHECK (DATALENGTH(vendorName)>=3),
)

SELECT * FROM MsVendor

--MsJacket
CREATE TABLE MsJacket(
	jacketID CHAR(5) PRIMARY KEY CHECK (jacketID LIKE 'JA[0-9][0-9][0-9]'),
	jacketName VARCHAR(70) NOT NULL,
	jacketStock INT NOT NULL,
	jacketPrice INT NOT NULL,
	CONSTRAINT checkJacketPrice CHECK (jacketPrice >= 25000)	
)
SELECT * FROM MsJacket

--MsMaterial
CREATE TABLE MsMaterial(
	materialID CHAR(5) PRIMARY KEY CHECK (materialID LIKE 'MA[0-9][0-9][0-9]'),
	materialName VARCHAR(70) NOT NULL,
	materialStock INT NOT NULL,
	materialPrice INT NOT NULL,
)
SELECT * FROM MsMaterial

--SalesTransaction
CREATE TABLE SalesTransaction(
	salesTransactionID CHAR(5) PRIMARY KEY CHECK (salesTransactionID LIKE 'SA[0-9][0-9][0-9]'),
	staffID CHAR (5) FOREIGN KEY REFERENCES MsStaff(staffID) ON UPDATE CASCADE ON DELETE CASCADE,
	customerID CHAR (5) FOREIGN KEY REFERENCES MsCustomer(customerID) ON UPDATE CASCADE ON DELETE CASCADE,
	salesTransactionDate DATE CHECK (salesTransactionDate LIKE '%2019%')
)
SELECT * FROM SalesTransaction
DROP TABLE SalesTransaction


--PurchaseTransaction
CREATE TABLE PurchaseTransaction(
	purchaseTransactionID CHAR(5) PRIMARY KEY CHECK (purchaseTransactionID LIKE 'PR[0-9][0-9][0-9]'),
	staffID CHAR (5) FOREIGN KEY REFERENCES MsStaff(staffID) ON UPDATE CASCADE ON DELETE CASCADE,
	vendorID CHAR (5) FOREIGN KEY REFERENCES MsVendor(vendorID) ON UPDATE CASCADE ON DELETE CASCADE,
	purchaseTransactionDate DATE CHECK (purchaseTransactionDate LIKE '%2019%')
)
SELECT * FROM PurchaseTransaction
DROP TABLE PurchaseTransaction


--DetailSalesTransaction
CREATE TABLE DetailSalesTransaction(
	salesTransactionID CHAR (5) FOREIGN KEY REFERENCES SalesTransaction(salesTransactionID) ON UPDATE CASCADE ON DELETE CASCADE,
	jacketID CHAR (5) FOREIGN KEY REFERENCES MsJacket(jacketID) ON UPDATE CASCADE ON DELETE CASCADE,
	jacketQty INT

)
SELECT * FROM DetailSalesTransaction
DROP TABLE DetailSalesTransaction

--DetailPurchaseTransaction
CREATE TABLE DetailPurchaseTransaction(
	purchaseTransactionID CHAR (5) FOREIGN KEY REFERENCES PurchaseTransaction(purchaseTransactionID) ON UPDATE CASCADE ON DELETE CASCADE,
	materialID CHAR (5) FOREIGN KEY REFERENCES MsMaterial(materialID) ON UPDATE CASCADE ON DELETE CASCADE,
	materialQty INT
	PRIMARY KEY(purchaseTransactionID, materialID)
)
SELECT * FROM DetailPurchaseTransaction


--DetailJacketMaterial
CREATE TABLE DetailJacketMaterial(
	jacketID CHAR (5) FOREIGN KEY REFERENCES MsJacket(jacketID) ON UPDATE CASCADE ON DELETE CASCADE,
	materialID CHAR (5) FOREIGN KEY REFERENCES MsMaterial(materialID) ON UPDATE CASCADE ON DELETE CASCADE,
	jacketMaterialQty INT
	PRIMARY KEY(jacketID, materialID)
)
SELECT * FROM DetailJacketMaterial

DROP DATABASE BlauJackeJacket