USE BlauJackeJacket

--1.	Display CustomerName, Transaction Date (obtained from the transaction date in �dd mon yyyy� format), 
--and Transaction Quantity (obtained from the sum of quantity) for every sales transaction which ID of the jacket is �JA002� 
--and the transaction happened on the 11th month

SELECT 
customerName, 
[Transaction Date] = CONVERT(VARCHAR,salesTransactionDate,106), 
[Transaction Quantity] = SUM(dst.jacketQty) 
FROM MsCustomer mc, SalesTransaction st, DetailSalesTransaction dst  
WHERE mc.customerID = st.CustomerID
AND st.salesTransactionID = dst.salesTransactionID
AND jacketID = 'JA002'
AND MONTH(salesTransactionDate) = 11
GROUP BY customerName, salesTransactionDate

--2. Display VendorName, Transaction Date (obtained from the transaction date in �dd/mm/yyyy� format),
-- and Maximum Quantity (obtained from the maximum of quantity) for each purchase transaction 
--that happened on an even day and has a material with the ID of �MA001�.

SELECT 
vendorName, 
[Transaction Date] = CONVERT(VARCHAR,purchaseTransactionDate, 103),
[Maximum Quantity] = max(dpt.materialQty)
FROM MsVendor mv, PurchaseTransaction pt, DetailPurchaseTransaction dpt
WHERE pt.vendorID = mv.vendorID 
AND pt.purchaseTransactionID = dpt.purchaseTransactionID
AND (DAY(purchaseTransactionDate) % 2) = 0
AND materialID = 'MA001'
GROUP BY vendorName, purchaseTransactionDate

--3. Display VendorName, Vendor Address (obtained from vendor address with �Street� replaced by �St.�), 
--Total Item (obtained from the sum of quantity), and Total Transaction (obtained from the count of the transaction) 
--for every purchase transaction with vendor name starts with �PT.� and the transaction happened on the 10th month.

SELECT 
vendorName, 
[Vendor Address] = REPLACE(vendorAddress, 'Street', 'St.'),
[Total Item] = SUM(dpt.materialQty),
[Total Transaction] = COUNT(pt.purchaseTransactionID)
FROM MsVendor mv, PurchaseTransaction pt, DetailPurchaseTransaction dpt
WHERE mv. vendorID = pt.vendorID 
AND pt.purchaseTransactionID = dpt.purchaseTransactionID 
AND vendorName LIKE 'PT.%' 
AND MONTH(purchaseTransactionDate) = 10
GROUP BY vendorName, vendorAddress

--4. Display StaffName, StaffGender (obtained from first letter of staff�s gender), CustomerName,
-- and Total Sales Transaction (obtained from the count of the transaction) for every sales transaction
-- that happened on an even day and the sum of the quantity is greater than or equal to 4.

SELECT 
staffName, 
[StaffGender] = LEFT(StaffGender,1),
customerName,
[Total Sales Transaction] = COUNT(st.SalesTransactionID)
fROM MsStaff ms, MsCustomer mc, SalesTransaction st, DetailSalesTransaction dst
WHERE ms.staffID = st.staffID 
AND mc.customerID = st.customerID
AND st.salesTransactionID = dst.salesTransactionID
AND (DAY(salesTransactionDate) % 2) = 0
GROUP BY staffName, staffGender, customerName
HAVING COUNT(st.SalesTransactionID) > 4

--5. Display CustomerName (obtained from customer name in uppercase format) and
-- CustomerGender (obtained from first letter of customer gender) for every sales transaction 
--that happened on the first day of the month and the quantity is greater than the average 
--quantity of all sales transaction.
--(alias subquery)

SELECT [CustomerName] = UPPER(CustomerName),
[CustomerGender] = LEFT(CustomerGender,1)
FROM MsCustomer mc, SalesTransaction st, DetailSalesTransaction dts,
(
	SELECT AVG(dts.jacketQty) AS avgJacketQty
	FROM DetailSalesTransaction 
) AS x
WHERE st.salesTransactionID = dts.salesTransactionID
AND st.customerID = mc.customerID
AND DAY(salesTransactionDate) = 1
AND dts.jacketQty > x.avgJacketQty


-- 6. Display VendorName, PurchaseDate (obtained from purchases date in �Mon dd, yyyy� format), 
--and MaterialName (obtained from the material name in lowercase format) for every purchase transaction with
-- a material price is greater than the average price of all materials and the vendor�s name ends with �Inc�.
-- (alias subquery)

SELECT 
vendorName,
[PurchaseDate] = CONVERT(VARCHAR, purchaseTransactionDate, 107),
[MaterialName] = LOWER(MaterialName)
FROM MsVendor mv, PurchaseTransaction pt, DetailPurchaseTransaction dpt, MsMaterial mm,
(
	SELECT AVG(materialPrice) AS avgMaterialPrice
	FROM MsMaterial
) AS x
WHERE mv.vendorID = pt.vendorID
AND pt.purchaseTransactionID = dpt.purchaseTransactionID
AND mm.materialID = dpt.materialID
AND materialPrice > x.avgMaterialPrice
AND vendorName LIKE '%Inc'

--7. Display CustomerName, Transaction Day (obtained from the name of the day of the transaction date, for example �Monday�),
-- Quantity (obtained from the quantity that ends with � piece(s)�), and 
--Total Price (obtained from the sum of the quantity times the price of the jacket) 
--for every sales transaction with the quantity is greater than the average quantity of all sales transaction quantity 
--and the Total Price is greater than 10000000. Sort the result by customer name in descending order.
--(alias subquery) 

SELECT 
customerName, 
[Transaction Day] = DATENAME(WEEKDAY,salesTransactionDate),
[Quantity] = qtyJacket,
[Total Price] = SUM(qtyJacket * JacketPrice) 
FROM MsCustomer mc, SalesTransaction st, DetailSalesTransaction dst, MsJacket mj,
(
	SELECT AVG(qtyJacket) AS qtyAvgJacket
	FROM DetailSalesTransaction 
)AS x
WHERE mc.customerID = st.customerID
AND st.salesTransactionID = dst.salesTransactionID 
AND mj.jacketID = dst.jacketID
AND (qtyJacket LIKE '%piece' OR qtyJacket LIKE '%pieces')
AND qtyJacket > x.qtyAvgJacket
GROUP BY customerName, salesTransactionDate, qtyJacket
HAVING  SUM(qtyJacket * JacketPrice) > 10000000
ORDER BY customerName DESC

--8.	Display VendorName, Transaction Date (obtained from purchases date in �dd mon yyyy� format), MaterialName, and
-- Material Number (obtained from last three characters of material ID) for every purchase transaction with the material stock is 
--greater than the average of all material stock. And the total price is greater than 20000 where the total price is obtained 
--from the sum of transaction quantity times material price. Sort the result by vendor name in ascending order.
--(alias subquery) 

SELECT 
vendorName,
[Transaction Date] = CONVERT(VARCHAR, purchaseTransactionDate, 106),
materialName,
[Material Number] = RIGHT(dpt.materialID, 3)
FROM MsVendor mv, PurchaseTransaction pt, DetailPurchaseTransaction dpt, MsMaterial mm,
(
	SELECT AVG(MaterialStock) AS avgMaterialStock
	FROM MsMaterial mm
)AS x
WHERE mv.vendorID = pt.vendorID
AND pt.purchaseTransactionID = dpt.purchaseTransactionID
AND mm.materialID = dpt.materialID
AND materialStock > x.avgMaterialStock
GROUP BY vendorName, purchaseTransactionDate, materialName, dpt.materialID
HAVING  SUM(qtyMaterial * materialPrice) > 20000
ORDER BY vendorName ASC 

--9. Create a view named �ViewPurchaseTransaction� to display VendorName, Total Purchase Quantity (obtained from the sum of quantity), 
--and Total Purchase Transaction (obtained from the count of purchase transaction) for every vendor whose name starts with �PT.� 
--and the Total Purchase Transaction is greater than 2.

CREATE VIEW viewPurchaseTransaction AS
	SELECT vendorName,
	[Total Purchase Quantity] = SUM(qtyMaterial),
	[Total Purchase Transaction] = COUNT(pt.purchaseTransactionID)
	FROM MsVendor mv, PurchaseTransaction pt, DetailPurchaseTransaction dpt
	WHERE vendorName LIKE 'PT.'
	AND mv.vendorID = pt.vendorID 
	AND pt.purchaseTransactionID = dpt.purchaseTransactionID
	GROUP BY vendorName
	HAVING COUNT(pt.purchaseTransactionID) > 2

SELECT * FROM viewPurchaseTransaction
DROP VIEW viewPurchaseTransaction

--10.	Create a view named �ViewSalesTransaction� to display StaffName, CustomerName, 
--Total Sales Transaction (obtained from the count of transaction), and Maximum Sales Quantity (obtained from the maximum of quantity)
-- for every sales transaction made by a customer whose name starts by �R� letter and the Total Sales Transaction is greater than 1.

CREATE VIEW viewSalesTransaction AS
	SELECT staffName, 
	customerName,
	[Total Sales Transaction] = COUNT(st.SalesTransactionId),
	[Maximum Sales Quantity] = MAX(qtyJacket)
	FROM MsStaff ms, MsCustomer mc, SalesTransaction st, DetailSalesTransaction dst
	WHERE ms.staffID = st.staffID
	AND mc.customerID = st.customerID
	AND st.salesTransactionID = dst.salesTransactionID
	AND customerName LIKE 'R%' 
	GROUP BY staffName, customerName
	HAVING COUNT(st.SalesTransactionId) > 1

SELECT * FROM viewSalesTransaction
DROP VIEW viewSalesTransaction

