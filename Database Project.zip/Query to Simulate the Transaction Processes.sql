USE BlauJackeJacket
GO

--d.Create insert queries using DML syntax to simulate how the data inserted to the database
-- if there is a new transaction with more than one product for sales transaction 
--and if there is a new transaction with more than one material for purchase transaction.

--there is a new transaction with more than one product for sales transaction 
--INSERT DATA
INSERT INTO MsCustomer VALUES ('CU014','Geraldine Stefie','Female','2000-09-22')
INSERT INTO salesTransaction VALUES ('SA027','ST001','CU014','2019/06/19')
INSERT INTO DetailSalesTransaction VALUES ('SA001','JA001',2),('SA001','JA002',2)
--UPDATE JACKET STOCK
UPDATE MsJacket SET
jacketStock -= 2
WHERE jacketID = 'JA001'

UPDATE MsJacket SET
jacketStock -= 2
WHERE jacketID = 'JA002'

--UPDATE JACKET Material
UPDATE MsMaterial SET
materialStock -=4
WHERE materialID = 'MA001'

UPDATE MsMaterial SET
materialStock -=2
WHERE materialID = 'MA002'

UPDATE MsMaterial SET
materialStock -=2
WHERE materialID = 'MA003'

--there is a new transaction with more than one material for purchase transaction
--INSERT DATA
INSERT INTO PurchaseTransaction VALUES('PR027','ST013','VE013','2019/03/28')
INSERT INTO DetailPurchaseTransaction VALUES ('PR027','MA001',4),('PR027','MA002',2)
	
--UPDATE MATERIAL STOCK
UPDATE MsMaterial SET
materialStock +=4
WHERE materialID = 'MA001'

UPDATE MsMaterial SET
materialStock +=2
WHERE materialID = 'MA002'