USE BlauJackeJacket

--MsCustomer
DELETE FROM MsCustomer
SELECT * FROM MsCustomer

INSERT INTO MsCustomer VALUES ('CU001','David Oktavian','Male','2000-01-13'),
('CU002','Alfred Setiaputra','Male','1999-02-14'),
('CU003','Alvyn','Male','1998-03-15'),
('CU004','Melvin','Male','1997-04-16'),
('CU005','David Padmawidjaja','Male','1996-05-17'),
('CU006','Nadhifa Tazkia Tsary','Female','1995-06-18'),
('CU007','Alvin Timothy Rustriarlan','Male','2000-07-19'),
('CU008','Harry','Male','1999-08-20'),
('CU009','Andiko Valentino','Male','1998-09-21'),
('CU010','Fiona Avangeline Jonathan','Female','1997-10-22'),
('CU011','Andika Rufiansyah','Male','1996-11-23'),
('CU012','Martin Christian','Male','1995-12-24'),
('CU013','Rico Winata','Male','2000-01-25')

--MsStaff
SELECT * FROM MsStaff
DELETE FROM MsStaff

INSERT INTO MsStaff VALUES ('ST001','Angelica Janissia','Female','1980-01-05','9000000'),
('ST002','Hari Husni','Male','1981-02-06','17000000'),
('ST003','Hardian Apriyanto','Male','1982-03-07','14000000'),
('ST004','Jason Octavianus','Male','1983-04-08','14000000'),
('ST005','Yonatan Sunjaya Kuhu','Male','1984-05-09','10000000'),
('ST006','Ferdian Ricky Agustine','Male','1985-06-10','5000000'),
('ST007','Aria Adam Kusuma','Male','1990-07-20','12000000'),
('ST008','Armand','Male','1991-08-21','17000000'),
('ST009','Yesaya Jason Setia Purnomo','Male','1992-09-22','8000000'),
('ST010','Frengki','Male','1993-12-23','5000000'),
('ST011','Jason Agustio Wijaya','Male','1994-10-24','12000000'),
('ST012','Alexander Angelo','Male','1995-11-25','4000000'),
('ST013','Farel Alfarizy','Male','1980-09-26','10000000')

--MsVendor
SELECT * FROM MsVendor
DELETE FROM MsVendor

INSERT INTO MsVendor VALUES ('VE001','PT. Odilo Aventis','Kirana Street','odilo.aventis@vendor.com'),
('VE002','Ignatius Jericho.Inc','Jelita Street','ignatius.jericho@vendor.com'),
('VE003','PT. Febrio Evan Hartanto','Flamboyan Street','febrio.hartanto@vendor.com'),
('VE004','PT. Vincent','Delima Street','vincent.vincent@vendor.com'),
('VE005','Suitanto Widjaya.Inc','Intan Street','suitanto.widjaya@vendor.com'),
('VE006','Elizabeth Angeline.Inc','Danau Biru Street','elizabeth.angeline@vendor.com'),
('VE007','Michael Wangsa Mulia.Inc','Gardenia Street','michael.mulia@vendor.com'),
('VE008','PT. Virto Hardiman','Harmoni Street','virto.hardiman@vendor.com'),
('VE009','Alex.Inc','Narada Street','alex.alex@vendor.com'),
('VE010','PT. Johan Felix Alfarrel','Lavender Street','johan.alfarrel@vendor.com'),
('VE011','Alessandro Ravael Kaho Berlian.Inc','Onyx Street','alessandro.berlian@vendor.com'),
('VE012','Kevin Adnyzio Sinuraya.Inc','Orlanda Street','kevin.sinuraya@vendor.com'),
('VE013','PT. Russel Ruben Theo','Mentari Street','russel.theo@vendor.com')

--MsJacket
SELECT * FROM MsJacket
DELETE FROM MsJacket

INSERT INTO MsJacket VALUES ('JA001','Wind Breaker',55,25000),
('JA002','Varsity',60,40000),
('JA003','Kulit',50,90000),
('JA004','Down Jacket',70,95000),
('JA005','Bomber/Flight',65,80000),
('JA006','Trench Coat',80,150000),
('JA007','Peacoat',100,100000),
('JA008','Chesterfield Coat',70,250000),
('JA009','Parka',75,300000),
('JA010','Duffle Coat',85,200000),
('JA011','Camel Coat',90,150000),
('JA012','Denim Jacket',90,400000),
('JA013','Tweet Jacket',95,80000)

--MsMaterial
SELECT * FROM MsMaterial
DELETE FROM MsMaterial

INSERT INTO MsMaterial VALUES ('MA001','Nilon',1000,121000),
('MA002','Polyster',1200,129000),
('MA003','Fleece',2000,129000),
('MA004','Kulit Sintetis',1300,105000),
('MA005','Bulu Angsa',1300,99000),
('MA006','Parasut',1400,59000),
('MA007','Katun',1500,115000),
('MA008','Kanvas',1600,110000),
('MA009','Fabric',1200,148000),
('MA010','Beludru',1100,82000),
('MA011','Cotton Twill',1100,108000),
('MA012','Taslan',1700,118000),
('MA013','Wol',1800,78000),
('MA014','Kasmir',2000,64000),
('MA015','Denim',1900,64000),
('MA016','Suede',2000,115000),
('MA017','Corduoy',1200,75000),
('MA018','Tweed',1400,150000)

--DetailJacketMaterial
SELECT * FROM DetailJacketMaterial
DELETE FROM DetailJacketMaterial

INSERT INTO DetailJacketMaterial VALUES ('JA001','MA001',4),
('JA001','MA002',2),
('JA002','MA003',2),
('JA003','MA004',1),
('JA004','MA001',2),
('JA004','MA005',1),
('JA005','MA006',5),
('JA005','MA003',4),
('JA006','MA006',2),
('JA006','MA007',5),
('JA006','MA008',5),
('JA007','MA009',3),
('JA008','MA010',4),
('JA009','MA011',2),
('JA009','MA008',3),
('JA009','MA012',5),
('JA010','MA013',4),
('JA011','MA013',3),
('JA011','MA014',3),
('JA012','MA015',1),
('JA013','MA016',2),
('JA013','MA017',1),
('JA013','MA018',3),
('JA013','MA007',1),
('JA013','MA013',4)


--salesTransaction
SELECT * FROM salesTransaction
DELETE FROM salesTransaction

INSERT INTO salesTransaction VALUES ('SA001','ST001','CU001','2019/01/02'),
('SA002','ST002','CU001','2019/02/03'),
('SA003','ST003','CU002','2019/03/04'),
('SA004','ST004','CU002','2019/04/05'),
('SA005','ST005','CU003','2019/05/06'),
('SA006','ST006','CU003','2019/06/07'),
('SA007','ST007','CU004','2019/07/08'),
('SA008','ST008','CU004','2019/08/09'),
('SA009','ST009','CU005','2019/09/10'),
('SA010','ST010','CU005','2019/10/11'),
('SA011','ST011','CU006','2019/11/12'),
('SA012','ST012','CU006','2019/12/13'),
('SA013','ST013','CU007','2019/11/14'),
('SA014','ST001','CU007','2019/10/15'),
('SA015','ST002','CU008','2019/09/16'),
('SA016','ST003','CU008','2019/08/17'),
('SA017','ST004','CU009','2019/05/02'),
('SA018','ST005','CU009','2019/11/20'),
('SA019','ST006','CU010','2019/10/21'),
('SA020','ST007','CU010','2019/09/22'),
('SA021','ST008','CU011','2019/08/23'),
('SA022','ST009','CU011','2019/07/24'),
('SA023','ST010','CU012','2019/03/25'),
('SA024','ST011','CU012','2019/04/26'),
('SA025','ST012','CU013','2019/11/27'),
('SA026','ST013','CU013','2019/03/27')


--detailSalesTransaction
SELECT * FROM DetailSalesTransaction
DELETE FROM DetailSalesTransaction

INSERT INTO DetailSalesTransaction VALUES ('SA001','JA001',1),
('SA001','JA002',2),
('SA001','JA003',3),
('SA001','JA004',1),
('SA002','JA005',2),
('SA002','JA006',2),
('SA002','JA007',1),
('SA003','JA008',1),
('SA003','JA009',1),
('SA003','JA010',1),
('SA003','JA011',1),
('SA003','JA012',1),
('SA003','JA013',1),
('SA004','JA001',3),
('SA004','JA002',4),
('SA004','JA003',1),
('SA005','JA004',2),
('SA005','JA005',2),
('SA005','JA006',4),
('SA005','JA007',5),
('SA006','JA008',5),
('SA007','JA009',6),
('SA007','JA010',3),
('SA008','JA011',3),
('SA008','JA012',2),
('SA010','JA013',1),
('SA010','JA001',1),
('SA010','JA002',2),
('SA011','JA003',2),
('SA011','JA004',2),
('SA012','JA005',2),
('SA013','JA006',3),
('SA014','JA007',3),
('SA014','JA008',3),
('SA015','JA009',3),
('SA016','JA010',4),
('SA016','JA011',4),
('SA017','JA012',4),
('SA017','JA013',2),
('SA018','JA001',1),
('SA018','JA002',2),
('SA019','JA003',3),
('SA019','JA004',4),
('SA020','JA005',2),
('SA021','JA006',1),
('SA021','JA007',2),
('SA022','JA008',3),
('SA023','JA009',2),
('SA024','JA010',2),
('SA025','JA011',1),
('SA026','JA012',1),
('SA026','JA013',2)


--PurchaseTransaction
SELECT * FROM PurchaseTransaction
DELETE FROM PurchaseTransaction

INSERT INTO PurchaseTransaction VALUES ('PR001','ST001','VE001','2019/01/02'),
('PR002','ST002','VE001','2019/02/03'),
('PR003','ST003','VE002','2019/03/04'),
('PR004','ST004','VE002','2019/04/05'),
('PR005','ST005','VE003','2019/05/06'),
('PR006','ST006','VE003','2019/06/07'),
('PR007','ST007','VE004','2019/07/08'),
('PR008','ST008','VE004','2019/08/09'),
('PR009','ST009','VE005','2019/09/10'),
('PR010','ST010','VE005','2019/10/11'),
('PR011','ST011','VE006','2019/11/12'),
('PR012','ST012','VE006','2019/12/13'),
('PR013','ST013','VE007','2019/11/14'),
('PR014','ST001','VE007','2019/10/15'),
('PR015','ST002','VE008','2019/09/16'),
('PR016','ST003','VE008','2019/08/17'),
('PR017','ST004','VE009','2019/05/02'),
('PR018','ST005','VE009','2019/11/20'),
('PR019','ST006','VE010','2019/10/21'),
('PR020','ST007','VE010','2019/09/22'),
('PR021','ST008','VE011','2019/08/23'),
('PR022','ST009','VE011','2019/07/24'),
('PR023','ST010','VE012','2019/03/25'),
('PR024','ST011','VE012','2019/04/26'),
('PR025','ST012','VE013','2019/11/27'),
('PR026','ST013','VE013','2019/03/28')

--detailPurchaseTransaction
SELECT * FROM DetailPurchaseTransaction
DELETE FROM DetailPurchaseTransaction

INSERT INTO DetailPurchaseTransaction VALUES ('PR001','MA001',1),
('PR001','MA002',2),
('PR001','MA003',3),
('PR001','MA004',1),
('PR002','MA005',2),
('PR002','MA006',2),
('PR002','MA007',1),
('PR003','MA008',1),
('PR003','MA009',1),
('PR003','MA010',1),
('PR003','MA011',1),
('PR003','MA012',1),
('PR003','MA013',1),
('PR004','MA001',3),
('PR004','MA002',4),
('PR004','MA003',1),
('PR005','MA004',2),
('PR005','MA005',2),
('PR005','MA006',4),
('PR005','MA007',5),
('PR006','MA008',5),
('PR007','MA009',6),
('PR007','MA010',3),
('PR008','MA011',3),
('PR009','MA012',2),
('PR010','MA013',1),
('PR010','MA001',1),
('PR010','MA002',2),
('PR011','MA003',2),
('PR011','MA004',2),
('PR012','MA005',2),
('PR013','MA006',3),
('PR014','MA007',3),
('PR014','MA008',3),
('PR015','MA009',3),
('PR016','MA010',4),
('PR016','MA011',4),
('PR017','MA012',4),
('PR017','MA013',2),
('PR018','MA001',1),
('PR018','MA002',2),
('PR019','MA003',3),
('PR019','MA004',4),
('PR020','MA005',2),
('PR021','MA006',1),
('PR021','MA007',2),
('PR022','MA008',3),
('PR023','MA009',2),
('PR024','MA010',2),
('PR025','MA011',1),
('PR026','MA012',1),
('PR026','MA013',2)