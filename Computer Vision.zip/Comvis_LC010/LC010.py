import cv2
from matplotlib import pyplot as plt
import numpy as np
import os
import math

#Face Recognition
trainning_path = 'images/train'
person_name = os.listdir(trainning_path)

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

face_list = []
class_list = []

#TRAIN -> ngecheckin satu", di looping
for idx, name in enumerate(person_name):
    person_path = trainning_path + '/' + name

    for image_name in os.listdir(person_path):
        full_img_path = person_path + '/' + image_name
        img = cv2.imread(full_img_path, 0)

        detected_face = face_cascade.detectMultiScale(img, scaleFactor=1.2, minNeighbors=5)

        if(len(detected_face) < 1):
            continue
        
        for face_rect in detected_face:
            x,y,h,w = face_rect
            face_img = img[y:y+h, x:x+w]

            face_list.append(face_img)
            class_list.append(idx)

face_recognizer = cv2.face.LBPHFaceRecognizer_create()
face_recognizer.train(face_list, np.array(class_list))

#TEST
test_path = 'images/test'
for img in os.listdir(test_path):
    full_test_img_path = test_path + '/' + img
    img_color = cv2.imread(full_test_img_path)
    img_gray = cv2.cvtColor(img_color, cv2.COLOR_BGR2GRAY)

    detected_face = face_cascade.detectMultiScale(img_gray, scaleFactor=1.2, minNeighbors=5)
    if(len(detected_face) < 1): #check ada mukanya ga
        continue

    for face_rect in detected_face:
        x,y,h,w = face_rect
        face_img = img_gray[y:y+h, x:x+w]

        result, confidence = face_recognizer.predict(face_img)
        #return result (id brp), confidence

        confidence = math.floor(confidence * 100)/100
        
        img_color = cv2.cvtColor(img_color, cv2.COLOR_BGR2RGB)
        cv2.rectangle(img_color, (x,y), (x+w,y+h), [0,255,0], 2)

        plt.imshow(img_color)
        plt.title(person_name[result]+': '+str(confidence)+'%')
        plt.show()
