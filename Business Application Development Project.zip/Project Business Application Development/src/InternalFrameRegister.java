import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import java.sql.ResultSet;

import javax.swing.*;
import javax.swing.text.JTextComponent;


public class InternalFrameRegister extends JInternalFrame {

    private JTextField tPhone;
    private JTextField tEmail;
    private JTextArea tAlamat;
    private JPasswordField passwordField;
    private ButtonGroup radioGender = new ButtonGroup();
    private Character a;
    Connect con = new Connect();
    boolean checkEmail;

    private boolean isNotValid(String s) {
        if (s.matches(".*[a-zA-Z].*")) {

            return true;
        }
        return false;
    }

    private boolean isValid(String s) {
        if (s.matches(".*[a-zA-Z].*") && s.matches(".*[0-9].*")) {
            return true;
        }
        return false;
    }

    private boolean isCheckEmail(String e){
        String query = "SELECT * FROM MEMBER WHERE Email ='" + e + "'";
        ResultSet rs = con.executeQuery(query);
        try{
            if(rs.next()){
                //found atau sudah terdaftar
                return false;
                //System.out.println("no");
            }
            else {
                //not found atau belum terdaftar
                return true;
                //System.out.println("yes");
            }

        }catch(Exception e1){
            e1.printStackTrace();

        }return true;
    }

    public boolean validRegis(String phone, String email, String alamat, String password, String formattedDate, String gender){

        if (phone == null) {
            JOptionPane.showMessageDialog(null, "All Fields Must be Filled a!");
        } else if (email== null) {
            JOptionPane.showMessageDialog(null, "All Fields Must be Filled b");
        } else if (alamat== null) {
            JOptionPane.showMessageDialog(null, "All Fields Must be Filled c");
        } else if (password== null) {
            JOptionPane.showMessageDialog(null, "All Fields Must be Filled d");
            //System.out.println(password);
        } else if (!isValid(password)) {
            System.out.println(email);
            JOptionPane.showMessageDialog(null, "Password is not Alphanumeric");
        } else if (gender == null) {
            JOptionPane.showMessageDialog(null, "Please Select Your Gender");
        } else if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(null, "Email format wrong");
        } else if (email.startsWith("@") || email.endsWith("@")) {
            JOptionPane.showMessageDialog(null, "Email can't start/ends with @");
        } else if (email.startsWith(".") || email.endsWith(".")) {
            JOptionPane.showMessageDialog(null, "Email can't start/ends with .");
        } else if (!email.contains("@")) {
            JOptionPane.showMessageDialog(null, "Email Must contain " + "@");
        } else if (password.length() < 6 || password.length() > 12) {
            JOptionPane.showMessageDialog(null, "Password Length Must be 6-12");
        } else if (!phone.startsWith("08")) {
            JOptionPane.showMessageDialog(null, "phone number must starts with 08");
        } else if (phone.length() != 11 && phone.length() != 12) {
            JOptionPane.showMessageDialog(null, "Phone number length must be 11 or 12 characters long");
        } else if (isNotValid(phone)) {
            JOptionPane.showMessageDialog(null, "phone number should be numberic");
        } else if (!alamat.endsWith("Street")) {
            JOptionPane.showMessageDialog(null, "Address must ends with " + '"' + "Street" + '"');
        } else if(!isCheckEmail(email)) {
            JOptionPane.showMessageDialog(null, "email anda sudah terdaftar");
        } else {
            return true;

        }return false;

    }


    //Initialize JIF Register
    @SuppressWarnings("serial")
    public InternalFrameRegister() {
        // TODO Auto-generated constructor stub
        super("Register", false, true, false, false);
        setVisible(true);
        setBounds(400, 200, 600, 500);

        JPanel panel = new JPanel();
        add(panel, BorderLayout.NORTH);

        JLabel lblRegister = new JLabel("Register");
        lblRegister.setFont(new Font("Tahoma", Font.BOLD, 27));
        panel.add(lblRegister);

        JPanel panel_1 = new JPanel();
        add(panel_1, BorderLayout.CENTER);
        panel_1.setLayout(new GridLayout(6, 2));

        JLabel lblEmail = new JLabel("Email");
        panel_1.add(lblEmail);

        tEmail = new JTextField();
        panel_1.add(tEmail);
        tEmail.setColumns(10);

        JLabel lblPassword = new JLabel("Password");
        panel_1.add(lblPassword);

        passwordField = new JPasswordField();
        panel_1.add(passwordField);

        JLabel lblPhone = new JLabel("Phone");
        panel_1.add(lblPhone);

        tPhone = new JTextField();
        panel_1.add(tPhone);
        tPhone.setColumns(10);

        JLabel lblDateOfBirth = new JLabel("Date of Birth");
        panel_1.add(lblDateOfBirth);

        SimpleDateFormat model = new SimpleDateFormat("dd-MMMMM-yyyy");
        JSpinner spinner = new JSpinner();
        Date today = new Date();
        spinner.setModel(new SpinnerDateModel(today, null, today, Calendar.DAY_OF_MONTH) {
        });
        spinner.setEditor(new JSpinner.DateEditor(spinner, model.toPattern()));
        panel_1.add(spinner);

        JLabel lblGender = new JLabel("Gender");
        panel_1.add(lblGender);

        JPanel panel_2 = new JPanel();
        panel_1.add(panel_2);
        panel_2.setLayout(new GridLayout(1, 0, 0, 0));

        JRadioButton radioMale = new JRadioButton("Male");
        panel_2.add(radioMale);
        radioGender.add(radioMale);


        JRadioButton radioFemale = new JRadioButton("Female");
        panel_2.add(radioFemale);
        radioGender.add(radioFemale);

        JLabel lblAddress = new JLabel("Address");
        panel_1.add(lblAddress);

        JTextArea tAlamat = new JTextArea();
        panel_1.add(tAlamat);

        JPanel panel_3 = new JPanel();
        add(panel_3, BorderLayout.SOUTH);

        JButton btnRegister = new JButton("Register");
        panel_3.add(btnRegister);
        btnRegister.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub

                String phone = tPhone.getText();
                String email = tEmail.getText();
                String alamat = tAlamat.getText();
                String password = passwordField.getText();
                String genderSelect=  "";
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = sdf.format(spinner.getValue());

                if (radioMale.isSelected()) {
                    genderSelect = "Male";
                } else {
                    genderSelect = "Female";
                }

                if(validRegis(phone, email, alamat, password, formattedDate, genderSelect)){
                    con.customerRegister(null, email, password, phone, formattedDate, genderSelect, alamat, "member");
                    JOptionPane.showMessageDialog(null, "Register Succeed");
                }


            }


        });
    }
}


