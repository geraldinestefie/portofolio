import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.table.DefaultTableModel;

public class AdminForm extends JFrame implements ActionListener {
    JMenuBar menubar = new JMenuBar();
    JMenu menuManages = new JMenu("Manages");
    JMenu menuOthers = new JMenu("Others");
    JMenuItem menuMembers = new JMenuItem("Members");
    JMenuItem menuCakes = new JMenuItem("Cakes");
    JMenuItem menuTransactions = new JMenuItem("Transactions");
    JMenuItem menuLogout = new JMenuItem("Logout");
    JLabel background = new JLabel();
    JTextArea jta = new JTextArea("LOGIN");
    private BufferedImage img;
    InternalFrameManageMember jifmember = new InternalFrameManageMember();
    InternalFrameManageCake jifcake = new InternalFrameManageCake();
    InternalFrameManageTransaction jiftransaction = new InternalFrameManageTransaction();
    InternalFrameLogin jiflogin = new InternalFrameLogin();

    JDesktopPane desktop = new JDesktopPane();

    void setMenu(){
        menubar.add(menuManages);
        menubar.add(menuOthers);

        menuManages.add(menuMembers);
        menuManages.add(menuCakes);
        menuManages.add(menuTransactions);

        menuOthers.add(menuLogout);

        //masukin action
        menuMembers.addActionListener(this);
        menuCakes.addActionListener(this);
        menuTransactions.addActionListener(this);
        menuLogout.addActionListener(this);
    }




    public AdminForm() {
        setSize(1500, 1000);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        ImageIcon img1 = new ImageIcon("backgroundproject.jpg");
        background = new JLabel("", img1, JLabel.CENTER);
        add(background);

        try {
            img = ImageIO.read(new File("backgroundproject.jpg"));
        } catch (Exception ex) {

        }

        desktop = new JDesktopPane() {
            @Override
            protected void paintComponent(Graphics grphcs) {
                super.paintComponent(grphcs);
                grphcs.drawImage(img, 0, 0, null);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(img.getWidth(), img.getHeight());
            }
        };

        desktop.add(jifmember);
        desktop.add(jifcake);
        desktop.add(jiftransaction);
        jifmember.setVisible(false);
        jifcake.setVisible(false);
        jiftransaction.setVisible(false);
        setContentPane(desktop);


        setTitle("Welcome, Admin" );
        setLocationRelativeTo(null);
        setVisible(true);
        setJMenuBar(menubar);
        setMenu();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource() == menuMembers) {


            jifmember.setVisible(true);
            jifcake.setVisible(false);
            jiftransaction.setVisible(false);

        }
        else if(e.getSource() == menuCakes) {

            jifcake.setVisible(true);
            jiftransaction.setVisible(false);
            jifmember.setVisible(false);

        }

        else if(e.getSource() == menuTransactions) {


            jiftransaction.setVisible(true);
            jifcake.setVisible(false);
            jifmember.setVisible(false);


        }else if (e.getSource() == menuLogout){
            dispose();

        }

    }
}
