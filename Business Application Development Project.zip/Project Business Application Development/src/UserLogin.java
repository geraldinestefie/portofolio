public class UserLogin {

    String emailCheck= null;

    public void tampungNama(String nama){
        setEmailCheck(nama);
        emailCheck = nama;
    }

    public UserLogin(){
        getEmailCheck();
    }
    public UserLogin(String email){


        System.out.println("INI EMAIL FINAL   " + email);
        setEmailCheck(email);


    }

    public String getEmailCheck() {
        return emailCheck;
    }

    public void setEmailCheck(String emailCheck) {
        this.emailCheck = emailCheck;
    }
}
