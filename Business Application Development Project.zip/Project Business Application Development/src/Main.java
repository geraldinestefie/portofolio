import java.lang.reflect.Member;

public class Main {
    public Main() {
        System.out.println("abc");

        new MainFrame();

    }



    public static void main(String[] args) {

        new Main();

    }

}




