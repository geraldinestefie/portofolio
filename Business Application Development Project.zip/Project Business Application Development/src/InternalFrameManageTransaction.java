import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.table.DefaultTableModel;

public class InternalFrameManageTransaction extends JInternalFrame{

    private JTextField tTransID;
    private JTable table;
    private JComboBox cbEmail;
    private JComboBox cbCakeName;
    Connect con = new Connect();
    Vector<Vector> data;
    Vector detail, header;
    private JSpinner sDate;
    private JSpinner sQty;
    int clickCounter = 0;

    public void load(ResultSet rs){

        header = new Vector<>();
        header.add("Transaction ID");
        header.add("Email");
        header.add("Cake Name");
        header.add("Quantity");
        header.add("Date");

        data = new Vector<>();


        try{
            while(rs.next()){
                int transid = rs.getInt("TransactionId");
                String email = rs.getString("Email");
                String cakename = rs.getString("CakeName");
                int qty = rs.getInt("Quantity");
                Date transdate = rs.getDate("TransactionDate");

                detail = new Vector<>();
                detail.add(transid);
                detail.add(email);
                detail.add(cakename);
                detail.add(qty);
                detail.add(transdate);

                data.add(detail);





            }
        }catch(Exception e){
            e.printStackTrace();
        }
        DefaultTableModel dtm = new DefaultTableModel(data, header);
        table.setModel(dtm);
    }

    @SuppressWarnings("unchecked")
    public void load1(ResultSet rs){

        try{
            while(rs.next()){
                String email = rs.getString("Email");
                cbEmail.addItem(email);

            }


        }catch(Exception e){
            System.out.println("error duplicate");

        }}

    public void load2(ResultSet rs){

        try{
            while(rs.next()){
                String cakename = rs.getString("CakeName");
                cbCakeName.addItem(cakename);
            }

        }catch(Exception e){
            System.out.println("error duplicate");

        }}

    @SuppressWarnings("unchecked")
    public InternalFrameManageTransaction() {
        // TODO Auto-generated constructor stub

        super("Manage Transaction", false, true, false, false);
        setVisible(true);
        setBounds(300,250,876, 386);



        JPanel panel = new JPanel();
        add(panel, BorderLayout.NORTH);

        JLabel lblManageTransaction = new JLabel("Manage Transaction");
        lblManageTransaction.setFont(new Font("Tahoma", Font.BOLD, 27));
        panel.add(lblManageTransaction);

        JPanel panel_1 = new JPanel();
        add(panel_1, BorderLayout.SOUTH);



        JPanel panel_2 = new JPanel();
        add(panel_2, BorderLayout.CENTER);
        panel_2.setLayout(new GridLayout(0, 1, 0, 0));


        table = new JTable();
        load(con.executeQuery("SELECT transaction.TransactionId, Email, CakeName,Quantity, TransactionDate "
                + "FROM transaction,detailtransaction,cake,member WHERE transaction.MemberId = member.MemberId"
                + " AND detailtransaction.CakeId = cake.CakeId AND transaction.TransactionId = detailtransaction.TransactionId"));

        JScrollPane scrollPane = new JScrollPane(table);
        panel_2.add(scrollPane);

        JPanel panel_4 = new JPanel();
        panel_2.add(panel_4);
        panel_4.setLayout(new GridLayout(3,4));

        JLabel lblTransID = new JLabel("Transaction ID");
        panel_4.add(lblTransID);

        tTransID = new JTextField();
        panel_4.add(tTransID);
        tTransID.setColumns(10);

        JPanel panel_3 = new JPanel();
        panel_4.add(panel_3);

        JPanel panel_5 = new JPanel();
        panel_4.add(panel_5);

        JLabel lblCakeName = new JLabel("Cake Name");
        panel_4.add(lblCakeName);

        cbCakeName = new JComboBox();
        cbCakeName.addItem("--Choose--");
        panel_4.add(cbCakeName);
        load2(con.executeQuery("SELECT CakeName FROM transaction,detailtransaction,cake,member WHERE transaction.MemberId = member.MemberId AND detailtransaction.CakeId = cake.CakeId AND transaction.TransactionId = detailtransaction.TransactionId"));


        JLabel lblEmail = new JLabel("Email");
        panel_4.add(lblEmail);

        cbEmail = new JComboBox();
        panel_4.add(cbEmail);
        cbEmail.addItem("--Choose--");
        load1(con.executeQuery("SELECT Email FROM transaction,detailtransaction,cake,member WHERE transaction.MemberId = member.MemberId AND detailtransaction.CakeId = cake.CakeId AND transaction.TransactionId = detailtransaction.TransactionId"));

        JLabel lblDate = new JLabel("Date");
        panel_4.add(lblDate);


        sDate = new JSpinner();
        SimpleDateFormat model = new SimpleDateFormat("dd-MMMM-yyyy");
        sDate = new JSpinner();
        Date today = new Date();
        sDate.setModel(new SpinnerDateModel(today,null,today,Calendar.DAY_OF_MONTH) {
        });
        sDate.setEditor(new JSpinner.DateEditor(sDate, model.toPattern()));
        panel_4.add(sDate);

        JLabel lblQty = new JLabel("Quantity");
        panel_4.add(lblQty);

        sQty = new JSpinner();
        panel_4.add(sQty);

        JButton btnDelete = new JButton("Delete");
        panel_1.add(btnDelete);



        //normal state

        tTransID.setEnabled(false);
        cbCakeName.setSelectedIndex(0);
        cbCakeName.setEnabled(false);
        Date today1 = new Date();
        sDate.setValue(today1);
        sDate.setEnabled(false);
        cbEmail.setSelectedIndex(0);
        cbEmail.setEnabled(false);
        sQty.setValue(0);
        sQty.setEnabled(false);

        btnDelete.setEnabled(true);
        table.getSelectionModel().clearSelection();

        btnDelete.addActionListener(new ActionListener() {


            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                clickCounter++;

                if(clickCounter == 1) {
                    tTransID.setEnabled(true);
                    cbCakeName.setEnabled(true);
                    sDate.setEnabled(true);
                    cbEmail.setEnabled(true);
                    sQty.setEnabled(true);

                    table.addMouseListener(new MouseListener() {

                        @Override
                        public void mouseReleased(MouseEvent e) {
                            // TODO Auto-generated method stub

                        }

                        @Override
                        public void mousePressed(MouseEvent e) {
                            // TODO Auto-generated method stub

                        }

                        @Override
                        public void mouseExited(MouseEvent e) {
                            // TODO Auto-generated method stub

                        }

                        @Override
                        public void mouseEntered(MouseEvent e) {
                            // TODO Auto-generated method stub

                        }

                        @Override
                        public void mouseClicked(MouseEvent e) {
                            // TODO Auto-generated method stub
                            DefaultTableModel model = (DefaultTableModel)table.getModel();
                            int selectedRowIndex = table.getSelectedRow();

                            tTransID.setText(model.getValueAt(selectedRowIndex, 0).toString());
                            cbEmail.setSelectedItem(model.getValueAt(selectedRowIndex, 1).toString());
                            cbCakeName.setSelectedItem(model.getValueAt(selectedRowIndex, 2).toString());
                            sQty.setValue(model.getValueAt(selectedRowIndex, 3));
                            sDate.setValue(model.getValueAt(selectedRowIndex, 4));


                        }
                    });

                }

                else {

                    if(table.getSelectionModel().isSelectionEmpty()) {
                        JOptionPane.showMessageDialog(null, "You haven't selected any row from table");
                    }
                    else{

                        int selectedRowIndex = table.getSelectedRow();
                        String transid = table.getValueAt(selectedRowIndex, 0).toString();

                        con.executeUpdate("DELETE FROM Transaction WHERE TransactionId ='" + transid + "'");
                        load(con.executeQuery("SELECT transaction.TransactionId, Email, CakeName,Quantity, TransactionDate "
                                + "FROM transaction,detailtransaction,cake,member WHERE transaction.MemberId = member.MemberId"
                                + " AND detailtransaction.CakeId = cake.CakeId AND transaction.TransactionId = detailtransaction.TransactionId"));


                        clickCounter = 0;

                        //normal state
                        tTransID.setEnabled(false);
                        cbCakeName.setSelectedIndex(0);
                        cbCakeName.setEnabled(false);
                        Date today1 = new Date();
                        sDate.setValue(today1);
                        sDate.setEnabled(false);
                        cbEmail.setSelectedIndex(0);
                        cbEmail.setEnabled(false);
                        sQty.setValue(0);
                        sQty.setEnabled(false);
                    }
                }
            }
        });

    }
}