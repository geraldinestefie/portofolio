import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import java.util.Date;
import java.util.Vector;
import java.util.Calendar;

import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class InternalFrameManageMember extends JInternalFrame implements ActionListener, MouseListener {

    private JTable table;
    public JPasswordField passwordField;
    public ButtonGroup radioGender = new ButtonGroup();
    public JRadioButton radioMale;
    public JRadioButton radioFemale;
    public JTextField tEmail;
    public JTextField tPhone;
    public JTextArea tAlamat;
    public JSpinner spinner;
    Connect con = new Connect();
    int clickCounter = 0;
    private JButton btnInsert;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnCancel;


    Vector<Vector> data;
    Vector detail, header;


    public void load(ResultSet rs) { //displayData


        header = new Vector<>();
        header.add("Email");
        header.add("Password");
        header.add("Phone");
        header.add("DOB");
        header.add("Gender");
        header.add("Address");

        data = new Vector<>();


        try {
            while (rs.next()) {
                String email = rs.getString("Email");
                String pass = rs.getString("Password");
                String phone = rs.getString("Phone");
                Date dob = rs.getDate("DOB");
                String gender = rs.getString("Gender");
                String address = rs.getString("Address");


                detail = new Vector<>();
                detail.add(email);
                detail.add(pass);
                detail.add(phone);
                detail.add(dob);
                detail.add(gender);
                detail.add(address);

                data.add(detail);


            }

        } catch (Exception e) {
            System.out.println("error duplicate");

        }

        DefaultTableModel dtm = new DefaultTableModel(data, header);
        table.setModel(dtm);

    }

    // constructor
    public InternalFrameManageMember() {

        super("Manage Member", false, true, false, false);
        setVisible(true);
        setBounds(300, 250, 876, 386);


        JPanel panel = new JPanel();
        add(panel, BorderLayout.NORTH);

        JLabel lblManageMember = new JLabel("Manage Member");
        lblManageMember.setFont(new Font("Tahoma", Font.BOLD, 27));
        panel.add(lblManageMember);

        JPanel panel_1 = new JPanel();
        add(panel_1, BorderLayout.SOUTH);


        JPanel panel_2 = new JPanel();
        add(panel_2, BorderLayout.CENTER);
        panel_2.setLayout(new GridLayout(0, 1, 0, 0));


        table = new JTable();
        load(con.executeQuery("SELECT * FROM MEMBER"));


        JScrollPane scrollPane = new JScrollPane(table);
        panel_2.add(scrollPane);

        JPanel panel_4 = new JPanel();
        panel_2.add(panel_4);
        panel_4.setLayout(new GridLayout(3, 4));

        JLabel lblEmail = new JLabel("Email");
        panel_4.add(lblEmail);

        tEmail = new JTextField();
        panel_4.add(tEmail);
        tEmail.setColumns(10);

        JLabel lblPhone = new JLabel("Phone");
        panel_4.add(lblPhone);

        tPhone = new JTextField();
        panel_4.add(tPhone);
        tPhone.setColumns(10);

        JLabel lblpass = new JLabel("Password");
        panel_4.add(lblpass);

        passwordField = new JPasswordField();
        panel_4.add(passwordField);

        JLabel lblDob = new JLabel("Date of Birth");
        panel_4.add(lblDob);

        SimpleDateFormat model = new SimpleDateFormat("dd-MMMM-yyyy");
        spinner = new JSpinner();
        Date today = new Date();
        spinner.setModel(new SpinnerDateModel(today, null, today, Calendar.DAY_OF_MONTH) {
        });
        spinner.setEditor(new JSpinner.DateEditor(spinner, model.toPattern()));
        panel_4.add(spinner);


        JLabel lblGender = new JLabel("Gender");
        panel_4.add(lblGender);

        JPanel panel_3 = new JPanel();
        panel_4.add(panel_3);
        panel_3.setLayout(new GridLayout(1, 2));

        radioMale = new JRadioButton("Male");
        radioGender.add(radioMale);
        panel_3.add(radioMale);

        radioFemale = new JRadioButton("Female");
        radioGender.add(radioFemale);
        panel_3.add(radioFemale);


        JLabel lblAddress = new JLabel("Address");
        panel_4.add(lblAddress);

        tAlamat = new JTextArea();
        panel_4.add(tAlamat);

        btnInsert = new JButton("Insert");
        panel_1.add(btnInsert);

        btnUpdate = new JButton("Update");
        panel_1.add(btnUpdate);

        btnDelete = new JButton("Delete");
        panel_1.add(btnDelete);

        btnCancel = new JButton("Cancel");
        panel_1.add(btnCancel);


        tAlamat.setEnabled(false);
        tEmail.setEnabled(false);
        tPhone.setEnabled(false);
        passwordField.setEnabled(false);
        spinner.setEnabled(false);
        radioFemale.setEnabled(false);
        radioMale.setEnabled(false);
        btnInsert.setEnabled(true);
        btnUpdate.setEnabled(true);
        btnDelete.setEnabled(true);
        btnCancel.setEnabled(false);
        tAlamat.setText("");
        tEmail.setText("");
        tPhone.setText("");
        passwordField.setText("");
        radioGender.clearSelection();
        Date today1 = new Date();
        spinner.setValue(today1);
        table.getSelectionModel().clearSelection();


        btnCancel.addActionListener(this);
        btnDelete.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnInsert.addActionListener(this);
        table.addMouseListener(this);
        table.isCellEditable(0, 0);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        InternalFrameRegister ifRegis = new InternalFrameRegister();

        if (e.getSource() == btnCancel) {
            tAlamat.setText("");
            tEmail.setText("");
            tPhone.setText("");
            passwordField.setText("");
            radioGender.clearSelection();
            Date today = new Date();
            spinner.setValue(today);
            table.getSelectionModel().clearSelection();

            btnUpdate.setText("Update");
            btnInsert.setText("Insert");
            btnCancel.setText("Cancel");
            btnDelete.setText("Delete");


            tAlamat.setEnabled(false);
            tEmail.setEnabled(false);
            tPhone.setEnabled(false);
            passwordField.setEnabled(false);
            spinner.setEnabled(false);
            radioFemale.setEnabled(false);
            radioMale.setEnabled(false);
            btnInsert.setEnabled(true);
            btnUpdate.setEnabled(true);
            btnDelete.setEnabled(true);
            btnCancel.setEnabled(false);
            clickCounter = 0;

        }
        else if (e.getSource() == btnDelete) {
                if (table.getSelectionModel().isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(null, "You haven't selected any row from table");
                } else {

                    int dialogButton = JOptionPane.YES_NO_CANCEL_OPTION;
                    int dialogResult = JOptionPane.showConfirmDialog(null, "Are You Sure?", "Delete Confirmation", dialogButton);


                    if (dialogResult == 0) {

                        int selectedRowIndex = table.getSelectedRow();
                        String email = table.getValueAt(selectedRowIndex, 0).toString();

                        con.executeUpdate("DELETE FROM MEMBER WHERE Email ='" + email + "'");
                        load(con.executeQuery("SELECT * FROM MEMBER"));
                        JOptionPane.showInternalMessageDialog(null, "Delete Berhasil");

                        clickCounter = 0;

                        //normal state
                        tAlamat.setText("");
                        tEmail.setText("");
                        tPhone.setText("");
                        passwordField.setText("");
                        radioGender.clearSelection();
                        Date today = new Date();
                        spinner.setValue(today);
                        table.getSelectionModel().clearSelection();

                        btnUpdate.setText("Update");
                        btnInsert.setText("Insert");
                        btnCancel.setText("Cancel");
                        btnDelete.setText("Delete");


                        tAlamat.setEnabled(false);
                        tEmail.setEnabled(false);
                        tPhone.setEnabled(false);
                        passwordField.setEnabled(false);
                        spinner.setEnabled(false);
                        radioFemale.setEnabled(false);
                        radioMale.setEnabled(false);
                        btnInsert.setEnabled(true);
                        btnUpdate.setEnabled(true);
                        btnDelete.setEnabled(true);
                        btnCancel.setEnabled(false);

                    } else if (dialogResult == 1) {
                        clickCounter = 1;
                        return;

                    }


                }


        }
        else if (e.getSource() == btnInsert) {
            clickCounter++;

            if(clickCounter == 1) {
                btnInsert.setText("Save Insert");
                tAlamat.setEnabled(true);
                tEmail.setEnabled(true);
                tPhone.setEnabled(true);
                passwordField.setEnabled(true);
                spinner.setEnabled(true);
                radioFemale.setEnabled(true);
                radioMale.setEnabled(true);

                btnUpdate.setEnabled(false);
                btnDelete.setEnabled(false);
                btnCancel.setEnabled(true);

                btnInsert.setEnabled(true);


                tAlamat.setText("");
                tEmail.setText("");
                tPhone.setText("");
                passwordField.setText("");
                radioGender.clearSelection();
                Date today = new Date();
                spinner.setValue(today);
                table.getSelectionModel().clearSelection();

                btnUpdate.setText("Update");
                btnInsert.setText("Insert");
                btnCancel.setText("Cancel");
                btnDelete.setText("Delete");

            }

            else {
                // TODO Auto-generated method stub
                String phone = tPhone.getText();
                String email = tEmail.getText();
                String alamat = tAlamat.getText();
                String password = passwordField.getText();
                System.out.println(password);
                String genderSelect = null;

                if (radioMale.isSelected()) {
                    genderSelect = "Male";
                } else if (radioFemale.isSelected()){
                    genderSelect = "Female";
                }

                String query = "SELECT * FROM MEMBER WHERE Email ='" + tEmail.getText() + "'";
                ResultSet rs = con.executeQuery(query);

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = sdf.format(spinner.getValue());



                if (ifRegis.validRegis(phone, email, alamat, password, formattedDate, genderSelect)) {
                   

                    JOptionPane.showMessageDialog(null, "Register Succeed");

                    con.customerRegister(null, email, password, phone, formattedDate,genderSelect, alamat, "member" );

                    load(con.executeQuery("SELECT * FROM MEMBER"));

                    //back to normal state
                    tAlamat.setText("");
                    tEmail.setText("");
                    tPhone.setText("");
                    passwordField.setText("");
                    radioGender.clearSelection();
                    Date today = new Date();
                    spinner.setValue(today);
                    table.getSelectionModel().clearSelection();

                    btnUpdate.setText("Update");
                    btnInsert.setText("Insert");
                    btnCancel.setText("Cancel");
                    btnDelete.setText("Delete");

                    tAlamat.setEnabled(false);
                    tEmail.setEnabled(false);
                    tPhone.setEnabled(false);
                    passwordField.setEnabled(false);
                    spinner.setEnabled(false);
                    radioFemale.setEnabled(false);
                    radioMale.setEnabled(false);
                    btnInsert.setEnabled(true);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                    btnCancel.setEnabled(false);

                    clickCounter = 0;
                }

            }
        }
        else if (e.getSource() == btnUpdate) {

            clickCounter++;

            if (clickCounter == 1) {
                tAlamat.setEnabled(true);
                tEmail.setEnabled(true);
                tPhone.setEnabled(true);
                passwordField.setEnabled(true);
                spinner.setEnabled(true);
                radioFemale.setEnabled(true);
                radioMale.setEnabled(true);

                btnUpdate.setEnabled(true);
                btnUpdate.setText("Save Update");

                btnInsert.setEnabled(false);
                btnDelete.setEnabled(false);
                btnCancel.setEnabled(true);


                table.addMouseListener(this);

                //gender
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                int selectedRowIndex = table.getSelectedRow();
                if (model.getValueAt(selectedRowIndex, 4).toString().equals("Male")) {
                    radioMale.doClick();
                } else if (model.getValueAt(selectedRowIndex, 4).toString().equals("Female")) {
                    radioFemale.doClick();
                }


            } else {

                if (table.getSelectionModel().isSelectionEmpty()) {
                    JOptionPane.showMessageDialog(null, "You haven't selected any row from table");
                } else {

                    String phone = tPhone.getText();
                    String email = tEmail.getText();
                    String alamat = tAlamat.getText();
                    String password = passwordField.getText();
                    String genderSelect = null;
                    int selectedRowIndex = table.getSelectedRow();
                    String emailditable = table.getValueAt(selectedRowIndex, 0).toString();

                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String formattedDate = sdf.format(spinner.getValue());

                    if (radioMale.isSelected()) {
                        genderSelect = "Male";
                    } else if (radioFemale.isSelected()) {
                        genderSelect = "Female";
                    }


                    if (ifRegis.validRegis(phone, email, alamat, password, formattedDate, genderSelect)) {
                        con.customerUpdate(null, email, password, phone, formattedDate, genderSelect, alamat, emailditable);
                        JOptionPane.showInternalMessageDialog(null, "Update Berhasil");
                    }else{
                        System.out.println("Update Fail");
                    }


                    load(con.executeQuery("SELECT * FROM MEMBER"));

                    tAlamat.setText("");
                    tEmail.setText("");
                    tPhone.setText("");
                    passwordField.setText("");
                    radioGender.clearSelection();
                    Date today = new Date();
                    spinner.setValue(today);
                    table.getSelectionModel().clearSelection();

                    btnUpdate.setText("Update");
                    btnInsert.setText("Insert");
                    btnCancel.setText("Cancel");
                    btnDelete.setText("Delete");

                    tAlamat.setEnabled(false);
                    tEmail.setEnabled(false);
                    tPhone.setEnabled(false);
                    passwordField.setEnabled(false);
                    spinner.setEnabled(false);
                    radioFemale.setEnabled(false);
                    radioMale.setEnabled(false);
                    btnInsert.setEnabled(true);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                    btnCancel.setEnabled(false);

                    clickCounter = 0;


                }
            }

        }

    }


    //INI MOUSE EVENT.
    @Override
    public void mouseClicked(MouseEvent e) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        int selectedRowIndex = table.getSelectedRow();

        tEmail.setText(model.getValueAt(selectedRowIndex, 0).toString());
        passwordField.setText(model.getValueAt(selectedRowIndex, 1).toString());
        tPhone.setText(model.getValueAt(selectedRowIndex, 2).toString());
        spinner.setValue(model.getValueAt(selectedRowIndex, 3));
        if (model.getValueAt(selectedRowIndex, 4).toString().equals("Male")) {
            radioMale.doClick();
        } else if (model.getValueAt(selectedRowIndex, 4).toString().equals("Female")) {
            radioFemale.doClick();
        } else {
            System.out.println("anda siapa");
        }
        tAlamat.setText(model.getValueAt(selectedRowIndex, 5).toString());

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
