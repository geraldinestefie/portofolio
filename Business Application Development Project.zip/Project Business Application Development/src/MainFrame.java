import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;


public class MainFrame extends JFrame {
    JMenuBar menubar = new JMenuBar();
    JMenu file = new JMenu("Menu");
    JMenuItem login = new JMenuItem("Login");
    JMenuItem register = new JMenuItem("Register");
    JMenuItem menuManage = new JMenuItem("M cake");
    JLabel background = new JLabel();
    JTextArea jta = new JTextArea("LOGIN");
    JDesktopPane desktop;
    private JLabel name, email;
    private BufferedImage img;
    InternalFrameRegister jifregister = new InternalFrameRegister();
    InternalFrameLogin jiflogin = new InternalFrameLogin();
    //InternalFrameBuyCake jifManage = new InternalFrameBuyCake();
    InternalFrameManageCake jifManage = new InternalFrameManageCake();
    //InternalFrameMyTransaction jifManage= new InternalFrameMyTransaction();


    void setMenu(){
        menubar.add(file);
        file.add(login);
        file.add(register);
        file.add(menuManage);

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                //  new FrameLogin();

                jifregister.setVisible(false);
                jiflogin.setVisible(true);



            }
        });

        register.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub

                jiflogin.setVisible(false);
                jifregister.setVisible(true);



            }
        });

        menuManage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jifManage.setVisible(true);
            }
        });
    }



    public MainFrame(){
        setSize(1500, 1000);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        ImageIcon img1 = new ImageIcon("backgroundproject.jpg");
        background = new JLabel("", img1, JLabel.CENTER);
        add(background);

        try {
            img = ImageIO.read(new File("backgroundproject.jpg"));
        } catch (Exception ex) {

        }

        desktop = new JDesktopPane() {
            @Override
            protected void paintComponent(Graphics grphcs) {
                super.paintComponent(grphcs);
                grphcs.drawImage(img, 0, 0, null);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(img.getWidth(), img.getHeight());
            }
        };

        desktop.add(jifregister);
        desktop.add(jiflogin);
        desktop.add(jifManage);
        jifregister.setVisible(false);
        jiflogin.setVisible(false);
        jifManage.setVisible(false);
        setContentPane(desktop);
        setTitle("La Torta Shop");
        setLocationRelativeTo(null);
        setVisible(true);
        setJMenuBar(menubar);
        setMenu();

    }

}