import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import java.util.Vector;
import java.util.Calendar;

public class InternalFrameManageCake extends JInternalFrame implements ActionListener, MouseListener {

    private ButtonGroup radioGender = new ButtonGroup();
    private JTextField tCakeId;
    @SuppressWarnings("rawtypes")
    private JComboBox cbBrand;
    private JSpinner spinner;
    private SpinnerModel sm = new SpinnerNumberModel(0, 0, null, 1);
    private JTextArea tPrice;
    private JTable table;
    private JTextField tCakeName;
    Connect con = new Connect();
    Vector<Vector> data;
    Vector detail, header;
    Vector<String> dataBrand = new Vector<>();
    Vector<Integer> vbrandId = new Vector<>();
    int clickCounter = 0;
    private JButton btnInsert, btnUpdate, btnDelete, btnCancel;

    private boolean isNotValid(String s) {
        if (s.matches(".*[a-zA-Z].*")) {
            return true;
        }
        return false;
    }

    public boolean validCake(String cakeName, String price, int stock){
        if (cakeName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All Fields Must be Filled!");
        } else if (price.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All Fields Must be Filled");
        } else if (cbBrand.getSelectedItem().equals("--Choose--")) {
            JOptionPane.showMessageDialog(null, "You have to choose a brand");
        } else if (isNotValid(price)){
            JOptionPane.showMessageDialog(null, "Price Not valid!");

        } else if(price.equalsIgnoreCase("0")){
            JOptionPane.showMessageDialog(null, "Price Can't be Zero!");

        }
        /*else if(stock == 0){
            JOptionPane.showMessageDialog(null, "Please Input Item Quantity");
        }*/
        else{
            return true;
        }return false;

    }


    public void load(ResultSet rs) {

        header = new Vector<>();
        header.add("Cake ID");
        header.add("Cake Name");
        header.add("Brand Name");
        header.add("Stock");
        header.add("Price");

        data = new Vector<>();


        try {
            while (rs.next()) {
                int cakeid = rs.getInt("CakeId");
                String cakename = rs.getString("CakeName");
                String brandname = rs.getString("BrandName");
                int stock = rs.getInt("Stock");
                int price = rs.getInt("Price");


                detail = new Vector<>();
                detail.add(cakeid);
                detail.add(cakename);
                detail.add(brandname);
                detail.add(stock);
                detail.add(price);

                data.add(detail);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        DefaultTableModel dtm = new DefaultTableModel(data, header);
        table.setModel(dtm);
    }

    @SuppressWarnings("unchecked")
    public void load1(ResultSet rs) {

        try {
            while (rs.next()) {
                String brandname = rs.getString("BrandName");
                cbBrand.addItem(brandname);
            }

        } catch (Exception e) {
            System.out.println("error duplicate");

        }
    }

    //constructor
    public InternalFrameManageCake() {

        super("Manage Cakes", false, true, false, false);
        setVisible(true);
        setBounds(300, 250, 876, 386);


        JPanel panel = new JPanel();
        add(panel, BorderLayout.NORTH);

        JLabel lblManageCake = new JLabel("Manage Cake");
        lblManageCake.setFont(new Font("Tahoma", Font.BOLD, 27));
        panel.add(lblManageCake);

        JPanel panel_1 = new JPanel();
        add(panel_1, BorderLayout.SOUTH);

        JPanel panel_2 = new JPanel();
        add(panel_2, BorderLayout.CENTER);
        panel_2.setLayout(new GridLayout(0, 1, 0, 0));

        //SYNTAX
        table = new JTable();
        load(con.executeQuery(
                "SELECT cakeid, cakename, brandname,stock,price FROM cake, brand " +
                "WHERE cake.BrandId = brand.BrandId ORDER BY cakeid"
        ));

        /*load(con.executeQuery(
                "SELECT * FROM cake"
        ));*/

        JScrollPane scrollPane = new JScrollPane(table);
        panel_2.add(scrollPane);

        JPanel panel_4 = new JPanel();
        panel_2.add(panel_4);
        panel_4.setLayout(new GridLayout(3, 4));

        JLabel lblCakeID = new JLabel("Cake ID");
        panel_4.add(lblCakeID);

        tCakeId = new JTextField();
        panel_4.add(tCakeId);
        tCakeId.setColumns(10);

        JPanel panel_3 = new JPanel();
        panel_4.add(panel_3);

        JPanel panel_5 = new JPanel();
        panel_4.add(panel_5);

        JLabel lblCakeName = new JLabel("Cake Name");
        panel_4.add(lblCakeName);

        tCakeName = new JTextField();
        panel_4.add(tCakeName);
        tCakeName.setColumns(10);

        JLabel lblBrand = new JLabel("Brand");
        panel_4.add(lblBrand);


        cbBrand = new JComboBox();
        panel_4.add(cbBrand);
        cbBrand.addItem("--Choose--");
        load1(con.executeQuery("SELECT * FROM Brand"));


        JLabel lblStock = new JLabel("Stock");
        panel_4.add(lblStock);


        spinner = new JSpinner(sm);
        panel_4.add(spinner);

        JLabel lblPrice = new JLabel("Price");
        panel_4.add(lblPrice);

        tPrice = new JTextArea();
        panel_4.add(tPrice);

        btnInsert = new JButton("Insert");
        panel_1.add(btnInsert);

        btnUpdate = new JButton("Update");
        panel_1.add(btnUpdate);

        btnDelete = new JButton("Delete");
        panel_1.add(btnDelete);

        btnCancel = new JButton("Cancel");
        panel_1.add(btnCancel);

        tCakeId.setEnabled(false);
        tCakeName.setEnabled(false);
        spinner.setEnabled(false);
        cbBrand.setEnabled(false);
        tPrice.setEnabled(false);

        btnInsert.setEnabled(true);
        btnUpdate.setEnabled(true);
        btnDelete.setEnabled(true);

        btnCancel.setEnabled(false);
        tCakeId.setText("");
        tCakeName.setText("");
        tPrice.setText("");
        spinner.setValue(0);
        table.getSelectionModel().clearSelection();

        table.addMouseListener(this);
        btnInsert.addActionListener(this);
        btnCancel.addActionListener(this);
        btnDelete.addActionListener(this);
        btnUpdate.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnInsert){
            clickCounter++;

            if (clickCounter == 1) {
                String rowCounter = Integer.toString(table.getRowCount());
                btnInsert.setText("Save Insert");

                //get the last row of cakeid value

                int lastCakeId = (int) table.getValueAt((table.getRowCount() - 1), 0);
                String textCakeId = Integer.toString(lastCakeId + 1);

                tCakeId.setText(textCakeId);
                tCakeId.setEnabled(false);

                tCakeName.setEnabled(true);
                tPrice.setEnabled(true);
                spinner.setEnabled(true);
                cbBrand.setEnabled(true);

                btnUpdate.setEnabled(false);
                btnDelete.setEnabled(false);
                btnCancel.setEnabled(true);

                btnInsert.setEnabled(true);
                btnInsert.setText("Save Insert");


                tCakeName.setText("");
                tPrice.setText("");
                spinner.setValue(0);
                table.getSelectionModel().clearSelection();
                cbBrand.setSelectedIndex(0);


            } else {
//					 TODO Auto-generated method stub
                int cakeId= Integer.parseInt(tCakeId.getText());
                String cakeName = tCakeName.getText();
                String price = tPrice.getText();

                int stock = (int) spinner.getValue();
                String selectedItem = (String) cbBrand.getSelectedItem();


                if (validCake(cakeName, price, stock)){ //ini buat dapetin nama kue
                    String query = "SELECT BrandId FROM Brand WHERE BrandName = '" + selectedItem + "'";
                    ResultSet rs = con.executeQuery(query);
                    String str= rs.toString();
                    int brandId= 0;
                    try {
                        if (rs.next()) {
                            //found atau sudah terdaftar
                            brandId = rs.getInt("BrandId");
                            vbrandId.add(brandId);
                            System.out.println("ini brandid: "+ brandId);

                        } else {
                            //not found atau belum terdaftar
                            System.out.println("ngaco");
                        }

                    } catch (Exception e1) {
                        e1.printStackTrace();

                    }
                    int priceInt = Integer.parseInt(price);
                    //insert cake
                    con.cakeInsert(cakeId, brandId, cakeName, priceInt, stock);
                    //load cake
                    load(con.executeQuery("SELECT cakeid, cakename, brandname,stock,price FROM cake, brand " +
                            "WHERE cake.BrandId = brand.BrandId ORDER BY cakeid"));

                    //bacKtoNormalState
                    tCakeId.setEnabled(false);
                    tCakeName.setEnabled(false);
                    spinner.setEnabled(false);
                    cbBrand.setEnabled(false);
                    tPrice.setEnabled(false);
                    vbrandId.clear();

                    btnInsert.setEnabled(true);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);

                    btnUpdate.setText("Update");
                    btnInsert.setText("Insert");
                    btnCancel.setText("Cancel");
                    btnDelete.setText("Delete");

                    btnCancel.setEnabled(false);
                    tCakeId.setText("");
                    tCakeName.setText("");
                    tPrice.setText("");
                    spinner.setValue(0);
                    table.getSelectionModel().clearSelection();
                    cbBrand.setSelectedIndex(0);
                    clickCounter = 0;
                }

            }

        }
        else if (e.getSource() == btnCancel){
            tCakeId.setEnabled(false);
            tCakeName.setEnabled(false);
            spinner.setEnabled(false);
            cbBrand.setEnabled(false);
            tPrice.setEnabled(false);

            btnInsert.setEnabled(true);
            btnUpdate.setEnabled(true);
            btnDelete.setEnabled(true);

            btnUpdate.setText("Update");
            btnInsert.setText("Insert");
            btnCancel.setText("Cancel");
            btnDelete.setText("Delete");

            btnCancel.setEnabled(false);
            tCakeId.setText("");
            tCakeName.setText("");
            tPrice.setText("");
            spinner.setValue(0);
            table.getSelectionModel().clearSelection();

            clickCounter = 0;

        }
        else if (e.getSource()== btnDelete){
            clickCounter++;
            if (clickCounter==1){
                tPrice.setEnabled(true);
                tCakeId.setEnabled(false);
                tCakeName.setEnabled(true);
                spinner.setEnabled(true);
                btnCancel.setEnabled(true);
                table.addMouseListener(this);

            }else{
                if (table.getSelectionModel().isSelectionEmpty()){
                    JOptionPane.showMessageDialog(null, "Choose Item to Delete");
                }else{
                    int dialogBtn = JOptionPane.YES_NO_CANCEL_OPTION;
                    int dialogRes= JOptionPane.showConfirmDialog(null, "Are You sure?");

                    if (dialogRes==0){
                        int selectedRowIndex = table.getSelectedRow();
                        String cakeName= table.getValueAt(selectedRowIndex, 1).toString();

                        con.executeUpdate("DELETE FROM cake WHERE cakeName ='"+ cakeName +"'");
                        load(con.executeQuery("SELECT cakeid, cakename, brandname,stock,price FROM cake, brand " +
                                "WHERE cake.BrandId = brand.BrandId ORDER BY cakeid"));
                        JOptionPane.showMessageDialog(null, "Delete Berhasil");

                        //normalState
                        tCakeId.setEnabled(false);
                        tCakeName.setEnabled(false);
                        spinner.setEnabled(false);
                        cbBrand.setEnabled(false);
                        tPrice.setEnabled(false);
                        vbrandId.clear();

                        btnInsert.setEnabled(true);
                        btnUpdate.setEnabled(true);
                        btnDelete.setEnabled(true);

                        btnUpdate.setText("Update");
                        btnInsert.setText("Insert");
                        btnCancel.setText("Cancel");
                        btnDelete.setText("Delete");

                        btnCancel.setEnabled(false);
                        tCakeId.setText("");
                        tCakeName.setText("");
                        tPrice.setText("");
                        spinner.setValue(0);
                        table.getSelectionModel().clearSelection();
                        cbBrand.setSelectedIndex(0);
                        clickCounter = 0;
                    }
                }
            }


        }
        else if (e.getSource()== btnUpdate){
            System.out.println("update");

            clickCounter++;
            if (clickCounter==1){
                tPrice.setEnabled(true);
                tCakeId.setEnabled(false);
                tCakeName.setEnabled(true);
                spinner.setEnabled(true);
                cbBrand.setEnabled(true);
                table.addMouseListener(this);
                btnInsert.setEnabled(false);
                btnDelete.setEnabled(false);
                btnCancel.setEnabled(true);
                table.addMouseListener(this);


            }else{

                if (table.getSelectionModel().isSelectionEmpty()){
                    JOptionPane.showMessageDialog(null, "Please Select");
                }else{
                    int cakeId= Integer.parseInt(tCakeId.getText());
                    String cakeName = tCakeName.getText();
                    String selectedItem = (String) cbBrand.getSelectedItem();
                    int stock = (int) spinner.getValue();
                    String price = tPrice.getText();

                    if (validCake(cakeName, price, stock)) { //ini buat dapetin nama kue
                        String query = "SELECT BrandId FROM Brand WHERE BrandName = '" + selectedItem + "'";
                        ResultSet rs = con.executeQuery(query);
                        String str = rs.toString();
                        int brandId = 0;
                        try {
                            if (rs.next()) {
                                //found atau sudah terdaftar
                                brandId = rs.getInt("BrandId");
                                vbrandId.add(brandId);
                                System.out.println("ini brandid: " + brandId);

                            } else {
                                //not found atau belum terdaftar
                                System.out.println("Not Found");
                            }

                        } catch (Exception e1) {
                            e1.printStackTrace();

                        }
                        int priceInt = Integer.parseInt(price);
                        //insert cake
                        //con.cakeInsert(cakeId, brandId, cakeName, priceInt, stock);
                        con.cakeUpdate(cakeId, brandId, cakeName, priceInt, stock);
                        //load cake
                        load(con.executeQuery("SELECT cakeid, cakename, brandname,stock,price FROM cake, brand " +
                                "WHERE cake.BrandId = brand.BrandId ORDER BY cakeid"));

                        //bacKtoNormalState
                        tCakeId.setEnabled(false);
                        tCakeName.setEnabled(false);
                        spinner.setEnabled(false);
                        cbBrand.setEnabled(false);
                        tPrice.setEnabled(false);
                        vbrandId.clear();

                        btnInsert.setEnabled(true);
                        btnUpdate.setEnabled(true);
                        btnDelete.setEnabled(true);

                        btnUpdate.setText("Update");
                        btnInsert.setText("Insert");
                        btnCancel.setText("Cancel");
                        btnDelete.setText("Delete");

                        btnCancel.setEnabled(false);
                        tCakeId.setText("");
                        tCakeName.setText("");
                        tPrice.setText("");
                        spinner.setValue(0);
                        table.getSelectionModel().clearSelection();
                        cbBrand.setSelectedIndex(0);
                        clickCounter = 0;
                    }
                }






            }
        }
        else if (e.getSource()== btnCancel){
            //bacKtoNormalState
            tCakeId.setEnabled(false);
            tCakeName.setEnabled(false);
            spinner.setEnabled(false);
            cbBrand.setEnabled(false);
            tPrice.setEnabled(false);
            vbrandId.clear();

            btnInsert.setEnabled(true);
            btnUpdate.setEnabled(true);
            btnDelete.setEnabled(true);

            btnUpdate.setText("Update");
            btnInsert.setText("Insert");
            btnCancel.setText("Cancel");
            btnDelete.setText("Delete");

            btnCancel.setEnabled(false);
            tCakeId.setText("");
            tCakeName.setText("");
            tPrice.setText("");
            spinner.setValue(0);
            table.getSelectionModel().clearSelection();
            cbBrand.setSelectedIndex(0);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        int selectedRowIndex = table.getSelectedRow();

        tCakeId.setText(model.getValueAt(selectedRowIndex, 0).toString());
        tCakeName.setText(model.getValueAt(selectedRowIndex, 1 ).toString());
        cbBrand.setSelectedItem(model.getValueAt(selectedRowIndex, 2).toString());
        spinner.setValue(model.getValueAt(selectedRowIndex, 3));
        tPrice.setText(model.getValueAt(selectedRowIndex, 4).toString());
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
