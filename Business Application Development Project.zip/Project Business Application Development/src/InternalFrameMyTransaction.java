import java.awt.BorderLayout;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Vector;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class InternalFrameMyTransaction extends JInternalFrame{

    private JTable table;
    Connect con = new Connect();
    Vector<Vector> data;
    Vector detail, header;
    int idMember = 0;

    public void load(ResultSet rs){

        header = new Vector<>();
        header.add("Cake Name");
        header.add("Brand");
        header.add("Date");
        header.add("Quantity");
        header.add("Price");
        header.add("Total Transaction");

        data = new Vector<>();


        try{
            while(rs.next()){
                String cakename = rs.getString("CakeName");
                String brandname = rs.getString("BrandName");
                Date transdate = rs.getDate("TransactionDate");
                int qty = rs.getInt("Quantity");
                int price = rs.getInt("Price");
                int totaltrans = rs.getInt("Quantity") * rs.getInt("Price");


                detail = new Vector<>();
                detail.add(cakename);
                detail.add(brandname);
                detail.add(transdate);
                detail.add(qty);
                detail.add(price);
                detail.add(totaltrans);

                data.add(detail);

            }
        }catch(Exception e){
            e.printStackTrace();
        }
        DefaultTableModel dtm = new DefaultTableModel(data, header);
        table.setModel(dtm);
    }
    public InternalFrameMyTransaction(String cariEmail) {
        // TODO Auto-generated constructor stub

        super("My Transaction", false, true, false, false);
        setVisible(true);
        setBounds(300,250,876, 386);

        JPanel panel = new JPanel();
        add(panel, BorderLayout.NORTH);

        JLabel lblMyTransaction = new JLabel("My Transaction");
        lblMyTransaction.setFont(new Font("Tahoma", Font.BOLD, 27));
        panel.add(lblMyTransaction);

        table = new JTable();

        //ganti dari email ke idmember
        ResultSet rs = con.executeQuery("SELECT * from member " +
                "WHERE Email = '" + cariEmail + "'");
        try {
            rs.next();
            this.idMember = rs.getInt("MemberId");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        load(con.viewMyTrans(idMember));

        JScrollPane scrollPane_1 = new JScrollPane(table);
        add(scrollPane_1, BorderLayout.CENTER);

    }

}