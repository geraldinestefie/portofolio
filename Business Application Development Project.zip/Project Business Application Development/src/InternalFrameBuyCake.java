import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class InternalFrameBuyCake extends JInternalFrame implements ActionListener, MouseListener {


    Connect con = new Connect();
    private ButtonGroup radioGender = new ButtonGroup();
    private JTextField tCakeId;
    private JTextArea tStock;
    private JTable table;
    private JTextField tCakeName;
    Vector<Vector> data;
    Vector detail, header;
    private JTextField tBrand;
    private JTextField tPrice;
    private JButton btnBuy, btnCancel;
    private JSpinner spinner;
    private SpinnerModel sm = new SpinnerNumberModel(0, 0, null, 1);
    int clickCounter = 0;
    int idMember=0;

    public void load(ResultSet rs) {


        header = new Vector<>();
        header.add("Cake ID");
        header.add("Cake Name");
        header.add("Brand Name");
        header.add("Stock");
        header.add("Price");

        data = new Vector<>();


        try {
            while (rs.next()) {
                int cakeid = rs.getInt("CakeId");
                String cakename = rs.getString("CakeName");
                String brandname = rs.getString("BrandName");
                int stock = rs.getInt("Stock");
                int price = rs.getInt("Price");


                detail = new Vector<>();
                detail.add(cakeid);
                detail.add(cakename);
                detail.add(brandname);
                detail.add(stock);
                detail.add(price);

                data.add(detail);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        DefaultTableModel dtm = new DefaultTableModel(data, header);
        table.setModel(dtm);
    }

    public InternalFrameBuyCake(String cariEmail) {
        // TODO Auto-generated constructor stub

        super("Buy Cake", false, true, false, false);
        setVisible(true);
        setBounds(300,250,876, 386);

        JPanel panel = new JPanel();
        add(panel, BorderLayout.NORTH);

        JLabel lblBuyCake = new JLabel("Buy Cake");
        lblBuyCake.setFont(new Font("Tahoma", Font.BOLD, 27));
        panel.add(lblBuyCake);

        JPanel panel_1 = new JPanel();
        add(panel_1, BorderLayout.SOUTH);

        JPanel panel_2 = new JPanel();
        add(panel_2, BorderLayout.CENTER);
        panel_2.setLayout(new GridLayout(0, 1, 0, 0));

        //SYNTAX
        table = new JTable();
        load(con.executeQuery(
                "SELECT cakeid, cakename, brandname,stock,price FROM cake, brand " +
                        "WHERE cake.BrandId = brand.BrandId ORDER BY cakeid"
        ));

        JScrollPane scrollPane = new JScrollPane(table);
        panel_2.add(scrollPane);

        JPanel panel_4 = new JPanel();
        panel_2.add(panel_4);
        panel_4.setLayout(new GridLayout(3,4));

        JLabel lblCakeID = new JLabel("Cake ID");
        panel_4.add(lblCakeID);

        tCakeId = new JTextField();
        panel_4.add(tCakeId);
        tCakeId.setColumns(10);

        JLabel lblBrand = new JLabel("Brand");
        panel_4.add(lblBrand);

        tBrand = new JTextField();
        panel_4.add(tBrand);
        tBrand.setColumns(10);

        JLabel lblCakeName = new JLabel("Cake Name");
        panel_4.add(lblCakeName);

        tCakeName = new JTextField();
        panel_4.add(tCakeName);
        tCakeName.setColumns(10);

        JLabel lblPrice = new JLabel("Price");
        panel_4.add(lblPrice);

        tPrice = new JTextField();
        panel_4.add(tPrice);
        tPrice.setColumns(10);

        JLabel lblStock = new JLabel("Stock");
        panel_4.add(lblStock);

        tStock = new JTextArea();
        panel_4.add(tStock);
        tStock.setColumns(10);

        JLabel lblQuantity = new JLabel("Quantity");
        panel_4.add(lblQuantity);

        spinner = new JSpinner(sm);
        panel_4.add(spinner);

        btnBuy = new JButton("Buy");
        panel_1.add(btnBuy);

        btnCancel = new JButton("Cancel");
        panel_1.add(btnCancel);

        tCakeId.setEnabled(false);
        tCakeName.setEnabled(false);
        tBrand.setEnabled(false);
        tPrice.setEnabled(false);
        tStock.setEnabled(false);
        btnCancel.setEnabled(false);
        spinner.setEnabled(false);
        table.addMouseListener(this);
        btnBuy.addActionListener(this);

        ResultSet rs = con.executeQuery("SELECT * from member " +
                "WHERE Email = '" + cariEmail + "'");
        try {
            rs.next();
            this.idMember = rs.getInt("MemberId");
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()== btnCancel){
            tCakeId.setEnabled(false);
            tCakeName.setEnabled(false);
            tBrand.setEnabled(false);
            tPrice.setEnabled(false);
            tStock.setEnabled(false);
            btnCancel.setEnabled(false);
            spinner.setEnabled(false);
        }else if (e.getSource()== btnBuy){
            String prodId;
            table.addMouseListener(this);
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            int selectedRowIndex = table.getSelectedRow();


            if (table.getSelectionModel().isSelectionEmpty()){
                JOptionPane.showMessageDialog(null, "Please Select Data!");
            }else{
                int stockLama = (int) model.getValueAt(selectedRowIndex, 3);
                int stockBaru = (int) spinner.getValue();
                int stockFinal= 0;
                int cakeId= (int) model.getValueAt(selectedRowIndex, 0);
                clickCounter++;
                if (clickCounter==1){
                    System.out.println("counter 1");
                    btnBuy.setText("Save Buy");
                    spinner.setEnabled(true);

                }else {
                    System.out.println("Save Buy");

                    if (stockLama< stockBaru ){
                        JOptionPane.showMessageDialog(null, "Quantity must less than equals "+ stockLama+ "!",  "Stock Alert", JOptionPane.INFORMATION_MESSAGE);

                    }else if (stockBaru == 0){
                        JOptionPane.showMessageDialog(null, "Stock tidak boleh 0", "Stock Alert", JOptionPane.INFORMATION_MESSAGE);
                    }else{
                        stockFinal= stockLama-stockBaru;
                        con.buyUpdate(stockFinal, cakeId, this.idMember, stockBaru);

                        load(con.executeQuery(
                                "SELECT cakeid, cakename, brandname,stock,price FROM cake, brand " +
                                        "WHERE cake.BrandId = brand.BrandId ORDER BY cakeid"
                        ));


                    }





                }
            }



        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        int selectedRowIndex = table.getSelectedRow();

        tCakeId.setText(model.getValueAt(selectedRowIndex, 0).toString());
        tCakeName.setText(model.getValueAt(selectedRowIndex, 1 ).toString());
        tBrand.setText(model.getValueAt(selectedRowIndex, 2).toString());
        tStock.setText(model.getValueAt(selectedRowIndex, 3).toString());
        tPrice.setText(model.getValueAt(selectedRowIndex, 4).toString());
        spinner.setValue(model.getValueAt(selectedRowIndex, 3));

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
