import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;


public class InternalFrameLogin extends JInternalFrame{

    JTextField tEmail;
    JPasswordField tPass;
    private JCheckBox checkbox;
    private JButton buttonLogin;
    Connect con = new Connect();
    boolean checkEmail;
    boolean checkPass;
    boolean checkRole;
    public String emailKirim;
    Vector<String> vemail = new Vector<>();

    String admin = "Eliz";



    private boolean isValid(String s) {
        if (s.matches(".*[a-zA-Z].*") && s.matches(".*[0-9].*")) {
            return true;
        }
        return false;
    }

    private boolean isCheckEmail(String e){

        String query1 = "SELECT * FROM MEMBER WHERE Email ='" + e + "'";
        ResultSet rs1 = con.executeQuery(query1);
        try{
            if(rs1.next()){

                //found email
                return true;
            }
            else {
                //not found
                return false;
            }

        }catch(Exception e1){
            e1.printStackTrace();

        } return false;

    }

    private String isCheckAdmin(String email, String pass) {

        String query = "SELECT RoleName FROM MEMBER WHERE Email ='" + email + "' AND Password = '" + pass + "'";
        ResultSet rs = con.executeQuery(query);

        try {
            if(rs.next()) {
                return rs.getString("RoleName");
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return "apadah";
    }

    private boolean isCheckPass (String e, String p){

        String query = "SELECT * FROM MEMBER WHERE Email ='" + e + "' AND Password = '" + p + "'";
        ResultSet rs = con.executeQuery(query);
        try{
            if(rs.next()){

                //found
                return true;
            }
            else {
                //not found
                return false;
            }

        }catch(Exception e1){
            e1.printStackTrace();

        } return false;

    }


    public String getEmailKirim() {
        return emailKirim;
    }

    public void setEmailKirim(String emailKirim) {
        this.emailKirim = emailKirim;
    }

    //Initialize JIF Login
    public InternalFrameLogin() {
        super("Login", false, true, false, false);
        setVisible(true);
        setBounds(400, 300,653, 269);


        JPanel panel = new JPanel();
        add(panel, BorderLayout.NORTH);

        JLabel lblLogin = new JLabel("Login");
        lblLogin.setFont(new Font("Tahoma", Font.BOLD, 27));
        panel.add(lblLogin);

        JPanel panel_1 = new JPanel();
        add(panel_1, BorderLayout.CENTER);
        panel_1.setLayout(new GridLayout(3, 2));

        JLabel lblEmail = new JLabel("Email");
        lblEmail.setFont(new Font("Tahoma", Font.BOLD, 16));
        panel_1.add(lblEmail);

        tEmail = new JTextField();
        panel_1.add(tEmail);
        tEmail.setColumns(10);


        JLabel lblPassword = new JLabel("Password");
        lblPassword.setFont(new Font("Tahoma", Font.BOLD, 16));
        panel_1.add(lblPassword);

        tPass = new JPasswordField();
        panel_1.add(tPass);

        JPanel panel_3 = new JPanel();
        panel_1.add(panel_3);

        JCheckBox checkbox = new JCheckBox("I agree with terms and conditions");
        checkbox.setFont(new Font("Tahoma", Font.BOLD, 16));
        panel_1.add(checkbox);

        JPanel panel_2 = new JPanel();
        add(panel_2, BorderLayout.SOUTH);

        JButton buttonLogin = new JButton("Login");
        panel_2.add(buttonLogin);
        buttonLogin.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                System.out.println("login");
                String email = tEmail.getText();

                @SuppressWarnings("deprecation")
                String pass = tPass.getText();

                if (email.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Email is Empty");
                } else if (!email.contains(".") || !email.contains("@")) {
                    JOptionPane.showMessageDialog(null, "Email format wrong");
                } else if (email.startsWith("@") || email.endsWith("@")) {
                    JOptionPane.showMessageDialog(null, "Email can't start/ends with @");
                } else if (email.startsWith(".") || email.endsWith(".")) {
                    JOptionPane.showMessageDialog(null, "Email can't start/ends with .");
                } else if (!isValid(pass)) {
                    JOptionPane.showMessageDialog(null, "Password is not Alphanumeric");
                } else if (!checkbox.isSelected()) {
                    JOptionPane.showMessageDialog(null, "agree checkbox ");
                } else if (!email.contains("@")){
                    JOptionPane.showMessageDialog(null, "Email Must contain "+ "@");
                } else if(isCheckEmail(email) == false){
                    JOptionPane.showMessageDialog(null, "Email anda belum terdaftar");
                } else if(isCheckPass(email, pass)== false) {
                    JOptionPane.showMessageDialog(null, "Password anda salah");
                } else {
                    JOptionPane.showMessageDialog(null, "login success");


                    if(isCheckAdmin(email, pass).equalsIgnoreCase("Admin")) {
                        new AdminForm();

                    }
                    else if(isCheckAdmin(email, pass).equalsIgnoreCase("Member")){
                       new MemberForm(email);

                    }
                    else {
                        System.out.println("Failed to login");

                    }

                }

            }

        });







    }


    public void abc (){
        String a= "abc"+ "Kontak";
    }
}