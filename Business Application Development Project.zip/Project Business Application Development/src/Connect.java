import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Connect {

    private Statement stmt;
    private ResultSet rs;
    private Connection con;
    private PreparedStatement pStat;

    public Connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            // Nanti db diubah sesuai nama db masing-masing
            con = DriverManager.getConnection("jdbc:mysql://localhost/newlatorta", "root", "");
            stmt = con.createStatement();

            System.out.println("Connected to the database..");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public ResultSet executeQuery(String query) {
        try {
            rs = stmt.executeQuery(query);
        } catch (Exception e) {
            System.out.println(e);
        }

        return rs;
    }

    public void executeUpdate(String query) {
        try {
            stmt.executeUpdate(query);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void executePreparedQuery(String query) {
        try {
            PreparedStatement pStat = con.prepareStatement(query);
            pStat.executeQuery();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void customerRegister(String memberId, String email, String password, String phone, String dob, String gender, String address, String rollName) {
        try {
            pStat = con.prepareStatement("insert into member(memberId, email, password, phone, dob, gender, address, roleName) values(?,?,?,?,?,?,?,?)");

            pStat.setString(1, memberId);

            pStat.setString(2, email);
            pStat.setString(3, password);
            pStat.setString(4, phone);
            pStat.setString(5, dob);
            pStat.setString(6, gender);
            pStat.setString(7, address);
            pStat.setString(8, rollName);
            pStat.execute();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void customerUpdate(String memberId, String email, String password, String phone, String dob, String gender, String address, String otherEmail) {
        executeUpdate("UPDATE member SET "
                + "Email = '" + email + "',"
                + "Password = '" + password + "',"
                + "Phone = '" + phone + "',"
                + "Gender = '" + gender + "',"
                + "DOB = '" + dob + "',"
                + "Address = '" + address + "' WHERE Email = '" + otherEmail + "'");

    }

    public void cakeInsert(int cakeId, int brandId, String cakeName, int price, int stock) {
        executeUpdate("INSERT INTO Cake VALUES(" +
                cakeId + "," +
                brandId + ",'" +
                cakeName + "',"
                + price + ","
                + stock + ")"
        );
    }

    public void cakeUpdate (int cakeId, int brandId, String cakeName, int price, int stock){
        executeUpdate("UPDATE cake SET "
                + "brandId = '" + brandId + "',"
                + "cakeName = '" + cakeName + "',"
                + "price = '" + price + "',"
                + "stock = '" + stock + "' WHERE cakeId = '" + cakeId + "'");
    }
    public ResultSet viewMyTrans (int idMember){
        rs = executeQuery("SELECT c.CakeName, b.BrandName, t.TransactionDate, dt.Quantity, c.Price " +
                        "from transaction as t, detailtransaction as dt, cake as c, brand as b " +
                        "where 	t.TransactionId = dt.TransactionId and " +
                        "dt.CakeId = c.CakeId and " +
                        "c.BrandId = b.BrandId and " +
                "t.MemberId ="+ idMember);
        return rs;
    }

    public void buyUpdate (int a, int cakeId, int memberId, int quantity){
        executeUpdate("UPDATE cake SET Stock= " + a + " WHERE CakeId = "+cakeId);
        rs = executeQuery("select (max(TransactionId)+1) 'newId' from transaction");
        int newId= -1;
        try {
            rs.next();
            newId = rs.getInt("newId");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        executeUpdate("INSERT INTO transaction" +
                "(`TransactionId`, `MemberId`, `TransactionDate`)VALUES " +
                "('"+newId+"', '"+memberId+"', '"+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+"') ");

        executeUpdate("INSERT INTO detailtransaction" +
                "(`TransactionId`, `CakeId`, `Quantity`)" +
                "VALUES ('"+newId+"', '"+cakeId+"', '"+quantity+"')");
    }

    public void saveBuy (){

    }


    /*SELECT c.CakeName, b.BrandName, t.TransactionDate, dt.Quantity, c.Price
    from transaction as t, detailtransaction as dt, cake as c, brand as b
    where 	t.TransactionId = dt.TransactionId and
    dt.CakeId = c.CakeId and
    c.BrandId = b.BrandId and
    t.MemberId = 6

            --manage transaction
    SELECT c.CakeName, t.TransactionDate, dt.Quantity, c.Price, t.TransactionId, m.Email
    from transaction as t, detailtransaction as dt, cake as c, member as m
    where 	t.TransactionId = dt.TransactionId and
    dt.CakeId = c.CakeId and
    t.MemberId = m.MemberId*/

}