
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Calendar;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.table.DefaultTableModel;

public class MemberForm extends JFrame implements ActionListener {
    JMenuBar menubar = new JMenuBar();
    JMenu menuTransactions = new JMenu("Transactions");
    JMenu menuOthers = new JMenu("Others");
    JMenuItem menuBuyItems = new JMenuItem("Buy Items");
    JMenuItem menuViewTransactions = new JMenuItem("View Transactions");
    InternalFrameBuyCake jifBuyCake = null;
    InternalFrameMyTransaction jifMyTrans = null;
    JMenuItem menuLogout = new JMenuItem("Logout");
    JPanel background = new JPanel();
    private BufferedImage img;
    private String emailTampung;
    InternalFrameLogin iLog= new InternalFrameLogin();
    String olMail = "";

    JDesktopPane desktop = new JDesktopPane();


 /*   public void setEmailCheck(String emailTampung) {
        this.emailTampung = emailTampung;
    }

    public String getEmailCheck() {
        return emailTampung;
    }
    String emailFinal = getEmailCheck()*/;


    void setMenu(){
        menubar.add(menuTransactions);
        menubar.add(menuOthers);

        menuTransactions.add(menuBuyItems);
        menuTransactions.add(menuViewTransactions);

        menuOthers.add(menuLogout);

        //masukin action
        menuBuyItems.addActionListener(this);
        menuViewTransactions.addActionListener(this);
        menuLogout.addActionListener(this);


    }


    public MemberForm(String email) {
        jifMyTrans= new InternalFrameMyTransaction(email);
        jifBuyCake = new InternalFrameBuyCake(email);

        this.olMail = email;

        setSize(1500, 1000);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Welcome, " + email.split("@")[0]);
        setLocationRelativeTo(null);
        setVisible(true);
        setJMenuBar(menubar);
        setMenu();


        try {
            img = ImageIO.read(new File("backgroundproject.jpg"));
        } catch (Exception ex) {

        }

        desktop = new JDesktopPane() {
            @Override
            protected void paintComponent(Graphics grphcs) {
                super.paintComponent(grphcs);
                grphcs.drawImage(img, 0, 0, null);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(img.getWidth(), img.getHeight());
            }
        };



       /* jifMyTrans.setVisible(false);
        jifBuyCake.setVisible(false);
       */ setContentPane(desktop);

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource() == menuBuyItems) {

            jifBuyCake = new InternalFrameBuyCake(olMail);
            desktop.add(jifBuyCake);
            setContentPane(desktop);
            jifBuyCake.setVisible(true);
            jifMyTrans.setVisible(false);




        }
        else if(e.getSource() == menuViewTransactions) {
            jifMyTrans= new InternalFrameMyTransaction(olMail);
            jifBuyCake.setVisible(false);
            jifMyTrans.setVisible(true);
            desktop.add(jifMyTrans);
            setContentPane(desktop);


        }

        else if(e.getSource() == menuLogout) {
            dispose();
        }

    }

}
